# Copyright (c) ipylab contributors.
# Distributed under the terms of the Modified BSD License.

from __future__ import annotations

import ipylab

if __name__ == "__main__":
    ipylab.plugin_manager.hook.launch_jupyterlab()
