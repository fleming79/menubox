"use strict";
(self["webpackChunkipylab"] = self["webpackChunkipylab"] || []).push([["lib_widget_js"],{

/***/ "./lib/observable_disposable.js":
/*!**************************************!*\
  !*** ./lib/observable_disposable.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ObservableDisposable: () => (/* binding */ ObservableDisposable)
/* harmony export */ });
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_0__);
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.

/**
 * A minimal ObservableDisposable.
 */
class ObservableDisposable {
    constructor() {
        this._disposed = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal(this);
        this._isDisposed = false;
    }
    get disposed() {
        return this._disposed;
    }
    get isDisposed() {
        return this._isDisposed;
    }
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this._isDisposed = true;
        this._disposed.emit(undefined);
        _lumino_signaling__WEBPACK_IMPORTED_MODULE_0__.Signal.clearData(this);
    }
}


/***/ }),

/***/ "./lib/utils.js":
/*!**********************!*\
  !*** ./lib/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   executeMethod: () => (/* binding */ executeMethod),
/* harmony export */   getNestedProperty: () => (/* binding */ getNestedProperty),
/* harmony export */   listProperties: () => (/* binding */ listProperties),
/* harmony export */   setNestedProperty: () => (/* binding */ setNestedProperty),
/* harmony export */   toFunction: () => (/* binding */ toFunction),
/* harmony export */   toJSONsubstituteCylic: () => (/* binding */ toJSONsubstituteCylic),
/* harmony export */   uniqueId: () => (/* binding */ uniqueId),
/* harmony export */   updateProperty: () => (/* binding */ updateProperty)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_1__);
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.


/**
 * Clean a dotted name prior to passing to one of these functions.
 *
 * @param subpath A dotted name
 * @returns
 */
function cleanSubpath(subpath) {
    return (subpath || '').replace('[', '.').replace(']', '');
}
/**
 * Get a nested property relative to `obj` using the `subpath` notation.
 */
function getNestedProperty({ obj, subpath, nullIfMissing = false, basename = '' }) {
    subpath = cleanSubpath(subpath);
    let subpath_ = '';
    const parts = subpath.split('.');
    let pname = '';
    for (let i = 0; i < parts.length; i++) {
        pname = parts[i];
        if (pname in obj) {
            obj = obj[pname];
            subpath_ = !subpath_ ? pname : `${subpath_}.${pname}`;
        }
        else {
            break;
        }
    }
    if (subpath_ !== subpath || typeof obj === 'undefined') {
        if (nullIfMissing) {
            return null;
        }
        if (obj instanceof Array && !isNaN(+pname)) {
            throw new Error(`Index ${subpath_}[${pname}] out of range for ` +
                `Array (${obj.length}) {${toJSONsubstituteCylic(obj)}}`);
        }
        basename = basename ? '<' + basename + '>.' : basename;
        throw new Error(`"${basename}${subpath}" not found!`);
    }
    return obj;
}
/**
 * Set a nested property at `subpath` relative to the obj on `obj`.
 */
function setNestedProperty({ obj, subpath, value, basename = '' }) {
    subpath = cleanSubpath(subpath);
    const objname = subpath.split('.').slice(0, -1).join('.');
    const key = subpath.split('.').slice(-1)[0];
    obj = getNestedProperty({ obj, subpath: objname, basename });
    obj[key] = value;
}
/**
 * Update the property. Equivalent to python: `dict.update`.
 */
async function updateProperty({ obj, subpath, value, basename = '' }) {
    obj = getNestedProperty({ obj, subpath, basename });
    return Object.assign(obj, value);
}
/**
 * Convert a string definition of a function to a function object.
 * @param code The function as a string: eg. 'function (a, b) { return a + b; }'
 * @returns
 */
function toFunction(code) {
    return new Function('return ' + code)();
}
function findAllProperties({ obj: obj, items = [], type = '', depth = 1, omitHidden = false }) {
    if (!obj || depth === 0) {
        return [...new Set(items)];
    }
    const props = Object.getOwnPropertyNames(obj).filter(value => omitHidden ? value.slice(0, 1) !== '_' : true);
    return findAllProperties({
        obj: Object.getPrototypeOf(obj),
        items: [...items, ...props],
        type,
        depth: depth - 1,
        omitHidden: omitHidden
    });
}
/**
 * List the properties of the object.
 *
 * This function is cyclic ref safe so is suitable for converting to json.
 */
function listProperties({ obj, type = '', depth = 1, omitHidden = false }) {
    const out = {};
    for (const name of findAllProperties({
        obj,
        items: [],
        type,
        depth,
        omitHidden
    })) {
        const obj_ = obj[name];
        let type_ = typeof obj_;
        let val = name;
        /*eslint no-fallthrough: ["error", { "commentPattern": "break[\\s\\w]*omitted" }]*/
        switch (type_) {
            case 'string':
            case 'number':
            case 'bigint':
            case 'boolean':
                out[name] = obj_;
                break;
            case 'undefined':
                out[name] = null;
                break;
            case 'object':
                if (obj_ instanceof Promise) {
                    val = name;
                    type_ = 'promise';
                }
                else if (obj_ instanceof _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal) {
                    type_ = 'signal';
                }
                else if (depth > 1) {
                    out[name] = listProperties({
                        obj: obj_,
                        type,
                        depth: depth - 1,
                        omitHidden
                    });
                    break;
                }
            // note: break is omitted intentionally
            default:
                if (!out[`<${type_}s>`]) {
                    out[`<${type_}s>`] = [val];
                }
                else {
                    out[`<${type_}s>`].push(val);
                    out[`<${type_}s>`] = out[`<${type_}s>`].sort();
                }
        }
    }
    // Sort alphabetically
    return Object.fromEntries(Object.entries(out).sort());
}
/**
 * Execute a method at subpath of obj.
 *
 * args are for the method.
 */
async function executeMethod({ obj, subpath, args, basename = '' }) {
    if (!subpath) {
        throw new Error('subpath required!');
    }
    subpath = cleanSubpath(subpath);
    const ownername = subpath.split('.').slice(0, -1).join('.');
    const owner = getNestedProperty({ obj, subpath: ownername, basename });
    let func = getNestedProperty({ obj, subpath, basename });
    func = func.bind(owner, ...args);
    return await func();
}
/**
 * Convert content replacing cyclic objects with a list of its properties.
 * @param value Content represent JSON
 * @returns
 */
function toJSONsubstituteCylic(value) {
    try {
        return JSON.stringify(value);
    }
    catch (_a) {
        // Assuming the error is due to circular reference
        if ((value === null || value === void 0 ? void 0 : value.payload) !== undefined) {
            const info = listProperties({
                obj: value.payload,
                omitHidden: true,
                depth: 3
            });
            info['WARNING'] =
                'This is a simplified representation because it contains circular references.';
            value.payload = info;
        }
        return JSON.stringify(value, _replacer);
    }
}
function _replacer(key, value) {
    // Filtering out properties
    if (typeof value !== 'object') {
        return value;
    }
    try {
        JSON.stringify(value);
        return value;
    }
    catch (_a) {
        const out = listProperties({
            obj: value,
            omitHidden: true,
            depth: 3
        });
        out['WARNING'] =
            'This is a simplified representation because it contains circular references.';
        return out;
    }
}
const _uniqueIDs = new WeakMap();
function uniqueId(obj) {
    if (!_uniqueIDs.has(obj)) {
        _uniqueIDs.set(obj, _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.UUID.uuid4());
    }
    return _uniqueIDs.get(obj);
}


/***/ }),

/***/ "./lib/widget.js":
/*!***********************!*\
  !*** ./lib/widget.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutoscrollModel: () => (/* reexport safe */ _widgets_autoscroll__WEBPACK_IMPORTED_MODULE_0__.AutoscrollModel),
/* harmony export */   AutoscrollView: () => (/* reexport safe */ _widgets_autoscroll__WEBPACK_IMPORTED_MODULE_0__.AutoscrollView),
/* harmony export */   CSSStyleSheetModel: () => (/* reexport safe */ _widgets_cssstylesheet__WEBPACK_IMPORTED_MODULE_4__.CSSStyleSheetModel),
/* harmony export */   CodeEditorModel: () => (/* reexport safe */ _widgets_code_editor__WEBPACK_IMPORTED_MODULE_1__.CodeEditorModel),
/* harmony export */   CodeEditorView: () => (/* reexport safe */ _widgets_code_editor__WEBPACK_IMPORTED_MODULE_1__.CodeEditorView),
/* harmony export */   CommandRegistryModel: () => (/* reexport safe */ _widgets_commands__WEBPACK_IMPORTED_MODULE_2__.CommandRegistryModel),
/* harmony export */   ConnectionModel: () => (/* reexport safe */ _widgets_connection__WEBPACK_IMPORTED_MODULE_3__.ConnectionModel),
/* harmony export */   DialogModel: () => (/* reexport safe */ _widgets_dialog__WEBPACK_IMPORTED_MODULE_5__.DialogModel),
/* harmony export */   IconModel: () => (/* reexport safe */ _widgets_icon__WEBPACK_IMPORTED_MODULE_6__.IconModel),
/* harmony export */   IconView: () => (/* reexport safe */ _widgets_icon__WEBPACK_IMPORTED_MODULE_6__.IconView),
/* harmony export */   IpylabModel: () => (/* reexport safe */ _widgets_ipylab__WEBPACK_IMPORTED_MODULE_7__.IpylabModel),
/* harmony export */   JupyterFrontEndModel: () => (/* reexport safe */ _widgets_frontend__WEBPACK_IMPORTED_MODULE_8__.JupyterFrontEndModel),
/* harmony export */   NotificationManagerModel: () => (/* reexport safe */ _widgets_notification__WEBPACK_IMPORTED_MODULE_9__.NotificationManagerModel),
/* harmony export */   PanelModel: () => (/* reexport safe */ _widgets_panel__WEBPACK_IMPORTED_MODULE_10__.PanelModel),
/* harmony export */   PanelView: () => (/* reexport safe */ _widgets_panel__WEBPACK_IMPORTED_MODULE_10__.PanelView),
/* harmony export */   ResizeBoxModel: () => (/* reexport safe */ _widgets_resize_box__WEBPACK_IMPORTED_MODULE_11__.ResizeBoxModel),
/* harmony export */   ResizeBoxView: () => (/* reexport safe */ _widgets_resize_box__WEBPACK_IMPORTED_MODULE_11__.ResizeBoxView),
/* harmony export */   SessionManagerModel: () => (/* reexport safe */ _widgets_sessions__WEBPACK_IMPORTED_MODULE_12__.SessionManagerModel),
/* harmony export */   ShellConnectionModel: () => (/* reexport safe */ _widgets_connection__WEBPACK_IMPORTED_MODULE_3__.ShellConnectionModel),
/* harmony export */   ShellModel: () => (/* reexport safe */ _widgets_shell__WEBPACK_IMPORTED_MODULE_13__.ShellModel),
/* harmony export */   SimpleOutputModel: () => (/* reexport safe */ _widgets_simple_output__WEBPACK_IMPORTED_MODULE_14__.SimpleOutputModel),
/* harmony export */   SimpleOutputView: () => (/* reexport safe */ _widgets_simple_output__WEBPACK_IMPORTED_MODULE_14__.SimpleOutputView),
/* harmony export */   SplitPanelModel: () => (/* reexport safe */ _widgets_split_panel__WEBPACK_IMPORTED_MODULE_15__.SplitPanelModel),
/* harmony export */   SplitPanelView: () => (/* reexport safe */ _widgets_split_panel__WEBPACK_IMPORTED_MODULE_15__.SplitPanelView),
/* harmony export */   TitleModel: () => (/* reexport safe */ _widgets_title__WEBPACK_IMPORTED_MODULE_16__.TitleModel)
/* harmony export */ });
/* harmony import */ var _widgets_autoscroll__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./widgets/autoscroll */ "./lib/widgets/autoscroll.js");
/* harmony import */ var _widgets_code_editor__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./widgets/code_editor */ "./lib/widgets/code_editor.js");
/* harmony import */ var _widgets_commands__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./widgets/commands */ "./lib/widgets/commands.js");
/* harmony import */ var _widgets_connection__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./widgets/connection */ "./lib/widgets/connection.js");
/* harmony import */ var _widgets_cssstylesheet__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./widgets/cssstylesheet */ "./lib/widgets/cssstylesheet.js");
/* harmony import */ var _widgets_dialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./widgets/dialog */ "./lib/widgets/dialog.js");
/* harmony import */ var _widgets_frontend__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./widgets/frontend */ "./lib/widgets/frontend.js");
/* harmony import */ var _widgets_icon__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./widgets/icon */ "./lib/widgets/icon.js");
/* harmony import */ var _widgets_ipylab__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./widgets/ipylab */ "./lib/widgets/ipylab.js");
/* harmony import */ var _widgets_notification__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./widgets/notification */ "./lib/widgets/notification.js");
/* harmony import */ var _widgets_panel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./widgets/panel */ "./lib/widgets/panel.js");
/* harmony import */ var _widgets_resize_box__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./widgets/resize_box */ "./lib/widgets/resize_box.js");
/* harmony import */ var _widgets_sessions__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./widgets/sessions */ "./lib/widgets/sessions.js");
/* harmony import */ var _widgets_shell__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./widgets/shell */ "./lib/widgets/shell.js");
/* harmony import */ var _widgets_simple_output__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./widgets/simple_output */ "./lib/widgets/simple_output.js");
/* harmony import */ var _widgets_split_panel__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./widgets/split_panel */ "./lib/widgets/split_panel.js");
/* harmony import */ var _widgets_title__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./widgets/title */ "./lib/widgets/title.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.




















/***/ }),

/***/ "./lib/widgets/autoscroll.js":
/*!***********************************!*\
  !*** ./lib/widgets/autoscroll.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutoScroll: () => (/* binding */ AutoScroll),
/* harmony export */   AutoscrollModel: () => (/* binding */ AutoscrollModel),
/* harmony export */   AutoscrollView: () => (/* binding */ AutoscrollView)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../version */ "./lib/version.js");
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.





/**
 *
 * Inspiration:  @jupyterlab/logconsole -> ScrollingWidget
 *
 * Implements a panel which autoscrolls the content.
 */
class AutoScroll extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget {
    constructor({ content, ...options }) {
        super(options);
        this._observer = null;
        this._view = options.view;
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.PanelLayout();
        this._sentinel = document.createElement('div');
        this._view.model.on('change:content', this.loadContent, this);
        this.loadContent();
    }
    /**
     * The content widget.
     */
    get content() {
        return this._content;
    }
    set content(content) {
        if (this._content === content) {
            return;
        }
        if (this._content) {
            this.layout.removeWidget(this._content);
        }
        this._content = content;
        if (content) {
            this.layout.addWidget(content);
        }
    }
    async loadContent() {
        const id = this._view.model.get('content');
        this.content = id ? await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.toLuminoWidget({ id }) : undefined;
        this.update();
    }
    scrollOnce() {
        if (this.enabled) {
            this._sentinel.scrollIntoView({ behavior: 'instant' });
        }
    }
    _disconnectObserver() {
        if (this._observer) {
            this._observer.disconnect();
            delete this._observer;
        }
    }
    update() {
        this._disconnectObserver();
        if (this.node.contains(this._sentinel)) {
            this.node.removeChild(this._sentinel);
        }
        this.enabled = this._view.model.get('enabled');
        if (!this.enabled) {
            this.node.onscrollend = null;
            return;
        }
        this._sentinel.textContent = this._view.model.get('sentinel_text') || '';
        if (this._view.model.get('mode') === 'start') {
            this.node.prepend(this._sentinel);
        }
        else {
            this.node.appendChild(this._sentinel);
        }
        this.node.onscrollend = (event) => {
            if (this.enabled) {
                this.scrollOnce();
            }
        };
        this._observer = new IntersectionObserver(args => {
            if (!args[0].isIntersecting) {
                this.scrollOnce();
            }
        }, { root: this.node });
        this._observer.observe(this._sentinel);
        this.scrollOnce();
    }
    processMessage(msg) {
        var _a;
        super.processMessage(msg);
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.processLuminoMessage(msg);
    }
    /**
     * Dispose the widget.
     *
     * This causes the view to be destroyed as well with 'remove'
     */
    dispose() {
        var _a, _b, _c;
        if (this.isDisposed) {
            return;
        }
        this._disconnectObserver();
        super.dispose();
        (_b = (_a = this._view) === null || _a === void 0 ? void 0 : _a.model) === null || _b === void 0 ? void 0 : _b.off('change:content', this.loadContent, this);
        (_c = this._view) === null || _c === void 0 ? void 0 : _c.remove();
        this._view = null;
    }
}
/**
 * The model for a logger.
 */
class AutoscrollModel extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'AutoscrollModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_4__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_4__.MODULE_VERSION,
            _view_name: 'AutoscrollView',
            _view_module: _version__WEBPACK_IMPORTED_MODULE_4__.MODULE_NAME,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_4__.MODULE_VERSION
        };
    }
}
/**
 * The view for a AutoScroll.
 */
class AutoscrollView extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetView {
    _createElement(tagName) {
        this.luminoWidget = new AutoScroll({
            view: this
        });
        return this.luminoWidget.node;
    }
    _setElement(el) {
        this.el = this.luminoWidget.node;
        this.$el = jquery__WEBPACK_IMPORTED_MODULE_2___default()(this.luminoWidget.node);
    }
    update(options) {
        super.update();
        this.luminoWidget.update();
    }
}


/***/ }),

/***/ "./lib/widgets/code_editor.js":
/*!************************************!*\
  !*** ./lib/widgets/code_editor.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CodeEditorModel: () => (/* binding */ CodeEditorModel),
/* harmony export */   CodeEditorView: () => (/* binding */ CodeEditorView),
/* harmony export */   IpylabCompleterProvider: () => (/* binding */ IpylabCompleterProvider),
/* harmony export */   KERNEL_PROVIDER_ID: () => (/* binding */ KERNEL_PROVIDER_ID)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/controls */ "webpack/sharing/consume/default/@jupyter-widgets/controls");
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyter_ydoc__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyter/ydoc */ "webpack/sharing/consume/default/@jupyter/ydoc");
/* harmony import */ var _jupyter_ydoc__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyter_ydoc__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/completer */ "webpack/sharing/consume/default/@jupyterlab/completer");
/* harmony import */ var _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/commands */ "webpack/sharing/consume/default/@lumino/commands");
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_commands__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
/* harmony import */ var _jupyterlab_tooltip__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/tooltip */ "webpack/sharing/consume/default/@jupyterlab/tooltip");
/* harmony import */ var _jupyterlab_tooltip__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_tooltip__WEBPACK_IMPORTED_MODULE_8__);
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.










class IpylabCodeEditorWrapper extends _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__.CodeEditorWrapper {
    constructor(options) {
        super(options);
        this._view = options.view;
    }
    processMessage(msg) {
        var _a;
        super.processMessage(msg);
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.processLuminoMessage(msg);
    }
    /**
     * Dispose of the resources held by the widget.
     */
    dispose() {
        var _a;
        // Do nothing if already disposed.
        if (this.isDisposed) {
            return;
        }
        super.dispose();
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.remove();
        this._view = null;
    }
}
class IpylabCompleter extends _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__.Completer {
    handleEvent(event) {
        super.handleEvent(event);
        if (!this.isHidden &&
            event.type === 'keydown' &&
            event.key === 'Enter') {
            // Select the value absorbing the keystroke.
            event.preventDefault();
            event.stopPropagation();
            event.stopImmediatePropagation();
            this.selectActive();
        }
    }
}
/**
 * The model for a code editor.
 */
class CodeEditorModel extends _ipylab__WEBPACK_IMPORTED_MODULE_9__.IpylabModel {
    constructor() {
        super(...arguments);
        this._syncRequired = false;
    }
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'CodeEditorModel',
            _view_name: 'CodeEditorView'
        };
    }
    initialize(attributes, options) {
        super.initialize(attributes, options);
        this.on('change:mime_type', this.updateMimeType);
        this.editorModel = new _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_2__.CodeEditor.Model({
            mimeType: this.get('mime_type'),
            sharedModel: (0,_jupyter_ydoc__WEBPACK_IMPORTED_MODULE_1__.createStandaloneCell)({ cell_type: 'code', source: '' })
        });
        this.editorModel.sharedModel.changed.connect(this.onSharedModelSourceChange, this);
    }
    async operation(op, payload) {
        switch (op) {
            case 'clearUndoHistory':
                return this.editorModel.sharedModel.clearUndoHistory();
            case 'setValue':
                this._syncRequired = true;
                this.editorModel.sharedModel.setSource(payload.value);
                this._syncRequired = false;
                return true;
            default:
                return await super.operation(op, payload);
        }
    }
    onSharedModelSourceChange() {
        if (!this._syncRequired) {
            this._syncRequired = true;
            setTimeout(async () => {
                if (this._syncRequired) {
                    try {
                        const value = this.editorModel.sharedModel.getSource();
                        const payload = { sync: this.get('_sync'), value };
                        await this.scheduleOperation('setValue', payload, 'auto');
                    }
                    finally {
                        this._syncRequired = false;
                    }
                }
            }, this.get('update_throttle_ms'));
        }
    }
    updateMimeType() {
        this.editorModel.mimeType = this.get('mime_type');
    }
    close(comm_closed) {
        var _a;
        (_a = this.editorModel) === null || _a === void 0 ? void 0 : _a.dispose();
        delete this.editorModel;
        return super.close(comm_closed);
    }
}
class CodeEditorView extends _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__.StringView {
    constructor() {
        super(...arguments);
        this._completerEnabled = false;
        this.disposables = new Set();
    }
    render() {
        super.render();
        this.luminoWidget.id = `ipylab-CodeEditor-${_lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__.UUID.uuid4()}`;
        this.className = this.luminoWidget.id;
        this.editorWidget = new IpylabCodeEditorWrapper({
            view: this,
            factory: _ipylab__WEBPACK_IMPORTED_MODULE_9__.IpylabModel.editorServices.factoryService.newInlineEditor,
            model: this.model.editorModel
        });
        this.editorWidget.id = this.editorWidget.id || _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__.UUID.uuid4();
        this.model.on('change:mimeType', this.updateCompleter, this);
        this.model.on('change:completer_invoke_keys', this.updateCompleter, this);
        this.model.on('change:editor_options', this.updateEditorOptions, this);
        this.updateCompleter();
        this.updateEditorOptions();
        this.editorWidget.addClass('ipylab-CodeEditor');
        this.editorWidget.addClass(this.className);
        this.el.appendChild(this.editorWidget.node);
        // Initialize the command registry with the bindings.
        const useCapture = true;
        // Setup the keydown listener for the editor.
        this.editorWidget.node.addEventListener('keydown', event => {
            Private.commands.processKeydownEvent(event);
        }, useCapture);
    }
    remove() {
        this.model.off('change:mimeType', this.updateCompleter, this);
        this.model.off('change:completer_invoke_keys', this.updateCompleter, this);
        this.model.off('change:editor_options', this.updateEditorOptions, this);
        this.disposeCompleter();
        this.disposeCommands();
        super.remove();
    }
    updateCompleter() {
        if (!this.model.editorModel.mimeType.toLowerCase().includes('python')) {
            this.disposeCompleter();
            this._loadCommands();
            return;
        }
        this._updateCompleter();
    }
    /**
     * Handle message sent to the front end.
     *
     * Used to focus or blur the widget.
     */
    handle_message(content) {
        if (content.do === 'focus') {
            this.editorWidget.editor.focus();
        }
        else if (content.do === 'blur') {
            this.editorWidget.editor.blur();
        }
    }
    /**
     * Provide a completer for the widget.
     */
    _updateCompleter() {
        // Set up a completer.
        if (!this.handler) {
            const editor = this.editorWidget.editor;
            const model = new _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__.CompleterModel();
            // const completer = new Completer({ editor, model });
            const completer = new IpylabCompleter({ editor, model, showDoc: true });
            const timeout = 1000;
            const provider = new IpylabCompleterProvider(this);
            const reconciliator = new _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__.ProviderReconciliator({
                context: {
                    widget: this.editorWidget,
                    editor
                },
                providers: [provider],
                timeout: timeout
            });
            this.handler = new _jupyterlab_completer__WEBPACK_IMPORTED_MODULE_3__.CompletionHandler({ completer, reconciliator });
            this.handler.editor = editor;
            completer.addClass('jp-ThemedContainer');
            completer.addClass(this.className);
            _lumino_widgets__WEBPACK_IMPORTED_MODULE_7__.Widget.attach(completer, document.body);
            this._disposeCompleter = () => {
                var _a;
                model.dispose();
                completer.dispose();
                (_a = this.handler) === null || _a === void 0 ? void 0 : _a.dispose();
                delete this.handler;
            };
        }
        this._loadCommands();
    }
    disposeCompleter() {
        if (this._disposeCompleter) {
            this._disposeCompleter();
            delete this._disposeCompleter;
        }
    }
    disposeCommands() {
        var _a;
        this.disposables.forEach(obj => obj.dispose());
        this.disposables.clear();
        (_a = this.tooltip) === null || _a === void 0 ? void 0 : _a.dispose();
    }
    _loadCommands() {
        // Add the commands.
        this.disposeCommands();
        const cmdInvokeId = `${this.className}:invoke-completer`;
        const cmdTooltip = `${this.className}:tooltip-invoke`;
        const cmdEvaluate = `${this.className}:evaluate-code`;
        const cmdUndo = `${this.className}:undo`;
        const cmdRedo = `${this.className}:redo`;
        const selector = `.${this.className}`;
        const keyBindings = this.model.get('key_bindings');
        // Undo
        this.disposables.add(Private.commands.addCommand(cmdUndo, {
            execute: async () => {
                this.model.editorModel.sharedModel.undo();
            }
        }));
        this.disposables.add(Private.commands.addKeyBinding({
            selector,
            keys: keyBindings['undo'],
            command: cmdUndo
        }));
        // Redo
        this.disposables.add(Private.commands.addCommand(cmdRedo, {
            execute: async () => {
                this.model.editorModel.sharedModel.redo();
            }
        }));
        this.disposables.add(Private.commands.addKeyBinding({
            selector,
            keys: keyBindings['redo'],
            command: cmdRedo
        }));
        if (!this.model.editorModel.mimeType.toLowerCase().includes('python')) {
            return;
        }
        // Invoke completer
        this.disposables.add(Private.commands.addCommand(cmdInvokeId, {
            execute: () => {
                this.handler.invoke();
            }
        }));
        this.disposables.add(Private.commands.addKeyBinding({
            selector,
            keys: keyBindings['invoke_completer'],
            command: cmdInvokeId
        }));
        // Invoke tooltip (inspect)
        this.disposables.add(Private.commands.addCommand(cmdTooltip, {
            execute: async () => {
                var _a;
                const editor = this.editorWidget.editor;
                const code = editor.model.sharedModel.getSource();
                const position = editor.getCursorPosition();
                const cursor_pos = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__.Text.jsIndexToCharIndex(editor.getOffsetAt(position), code);
                const payload = { code, cursor_pos };
                const msg = await this.model.scheduleOperation('requestInspect', payload, 'auto');
                (_a = this.tooltip) === null || _a === void 0 ? void 0 : _a.dispose();
                if (msg) {
                    this.tooltip = new _jupyterlab_tooltip__WEBPACK_IMPORTED_MODULE_8__.Tooltip({
                        anchor: this.editorWidget,
                        bundle: msg.data,
                        editor: this.editorWidget.editor,
                        rendermime: _ipylab__WEBPACK_IMPORTED_MODULE_9__.IpylabModel.rendermime
                    });
                    this.tooltip.addClass(this.className);
                    _lumino_widgets__WEBPACK_IMPORTED_MODULE_7__.Widget.attach(this.tooltip, document.body);
                }
            }
        }));
        this.disposables.add(Private.commands.addKeyBinding({
            selector,
            keys: keyBindings['invoke_tooltip'],
            command: cmdTooltip
        }));
        // Evaluate
        this.disposables.add(Private.commands.addCommand(cmdEvaluate, {
            execute: async () => {
                const editor = this.editorWidget.editor;
                const selection = editor.getSelection();
                const start = editor.getOffsetAt(selection.start);
                const end = editor.getOffsetAt(selection.end);
                const code = editor.model.sharedModel
                    .getSource()
                    .substring(start, end);
                await this.model.scheduleOperation('evaluateCode', { code }, 'auto');
            }
        }));
        this.disposables.add(Private.commands.addKeyBinding({
            selector,
            keys: keyBindings['evaluate'],
            command: cmdEvaluate
        }));
    }
    updateEditorOptions() {
        const options = this.model.get('editor_options');
        this.editorWidget.editor.setOptions(options);
    }
}
const KERNEL_PROVIDER_ID = 'CompletionProvider:ipylab:kernel';
/**
 * A kernel connector for completion handlers borrowed from Jupyterlab.
 */
class IpylabCompleterProvider {
    constructor(view) {
        this.identifier = KERNEL_PROVIDER_ID;
        this.rank = 550;
        this.renderer = null;
        this._view = view;
    }
    /**
     * The kernel completion provider is applicable only if the kernel is available.
     * @param context - additional information about context of completion request
     */
    async isApplicable(context) {
        return true;
    }
    /**
     * Fetch completion requests.
     *
     * @param request - The completion request text and details.
     */
    async fetch(request, context) {
        const contents = {
            code: request.text,
            cursor_pos: request.offset
        };
        const response = await this._view.model.scheduleOperation('requestComplete', contents, 'auto');
        if (response.status !== 'ok') {
            throw new Error('Completion fetch failed to return successfully.');
        }
        const items = new Array();
        const metadata = response.metadata._jupyter_types_experimental;
        response.matches.forEach((label, index) => {
            if (metadata && metadata[index]) {
                items.push({
                    label,
                    type: metadata[index].type,
                    insertText: metadata[index].text
                });
            }
            else {
                items.push({ label });
            }
        });
        return {
            start: response.cursor_start,
            end: response.cursor_end,
            items
        };
    }
    /**
     * Kernel provider will use the inspect request to lazy-load the content
     * for document panel.
     */
    async resolve(item, context, patch) {
        const { editor, session } = context;
        if (session && editor) {
            let code = editor.model.sharedModel.getSource();
            const position = editor.getCursorPosition();
            let offset = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_4__.Text.jsIndexToCharIndex(editor.getOffsetAt(position), code);
            if (patch) {
                const { start, value } = patch;
                code = code.substring(0, start) + value;
                offset = offset + value.length;
            }
            const contents = {
                code,
                cursor_pos: offset,
                detail_level: 0
            };
            const msg = await this._view.model.scheduleOperation('requestInspect', contents, 'auto');
            const value = msg.content;
            if (value.status !== 'ok' || !value.found) {
                return item;
            }
            item.documentation = value.data['text/plain'];
            return item;
        }
        return item;
    }
    /**
     * Kernel provider will activate the completer in continuous mode after
     * the `.` character.
     */
    shouldShowContinuousHint(visible, changed) {
        const sourceChange = changed.sourceChange;
        // eslint-disable-next-line eqeqeq
        if (sourceChange == null) {
            return true;
        }
        // eslint-disable-next-line eqeqeq
        if (sourceChange.some(delta => delta.delete != null)) {
            return false;
        }
        return sourceChange.some(delta => 
        // eslint-disable-next-line eqeqeq
        delta.insert != null &&
            (delta.insert === '.' || (!visible && delta.insert.trim().length > 0)));
    }
}
/**
 * A namespace for private data
 */
var Private;
(function (Private) {
    Private.commands = new _lumino_commands__WEBPACK_IMPORTED_MODULE_5__.CommandRegistry();
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/widgets/commands.js":
/*!*********************************!*\
  !*** ./lib/widgets/commands.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CommandRegistryModel: () => (/* binding */ CommandRegistryModel)
/* harmony export */ });
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/commands */ "webpack/sharing/consume/default/@lumino/commands");
/* harmony import */ var _lumino_commands__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_commands__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
/* harmony import */ var _observable_disposable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../observable_disposable */ "./lib/observable_disposable.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.



/**
 * The model for a command registry.
 */
class CommandRegistryModel extends _ipylab__WEBPACK_IMPORTED_MODULE_1__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'CommandRegistryModel'
        };
    }
    async ipylabInit(base = null) {
        if (!base) {
            base =
                this.get('name') === 'Jupyterlab'
                    ? _ipylab__WEBPACK_IMPORTED_MODULE_1__.IpylabModel.app.commands
                    : new _lumino_commands__WEBPACK_IMPORTED_MODULE_0__.CommandRegistry();
        }
        await super.ipylabInit(base);
    }
    setReady() {
        this.base.commandChanged.connect(this.sendCommandList, this);
        this.sendCommandList();
        super.setReady();
    }
    /**
     * Close model
     *
     * @param comm_closed - true if the comm is already being closed. If false, the comm will be closed.
     *
     * @returns - a promise that is fulfilled when all the associated views have been removed.
     */
    close(comm_closed = false) {
        var _a, _b;
        (_b = (_a = this === null || this === void 0 ? void 0 : this.base) === null || _a === void 0 ? void 0 : _a.commandChanged) === null || _b === void 0 ? void 0 : _b.disconnect(this.sendCommandList, this);
        return super.close(comm_closed);
    }
    async operation(op, payload) {
        switch (op) {
            case 'execute':
                return await this.base.execute(payload.id, payload.args);
            case 'addCommand':
                return await this.addCommand(payload);
            default:
                return await super.operation(op, payload);
        }
    }
    /**
     * Send the list of commands to the backend.
     */
    sendCommandList(sender, args) {
        if (args && args.type !== 'added' && args.type !== 'removed') {
            return;
        }
        this.set('all_commands', this.base.listCommands());
        this.save_changes();
    }
    /**
     * Add a new command to the command registry.
     *
     * @param payload The command options.
     */
    async addCommand(options) {
        const { id, isToggleable, icon } = options;
        // Make a new object and define functions so we can dynamically update.
        delete options.icon;
        const isToggled = isToggleable ? () => { var _a; return (_a = options.isToggled) !== null && _a !== void 0 ? _a : true; } : null;
        const mappings = {
            caption: () => { var _a; return (_a = options.caption) !== null && _a !== void 0 ? _a : ''; },
            className: () => { var _a; return (_a = options.className) !== null && _a !== void 0 ? _a : ''; },
            dataset: () => { var _a; return (_a = options.dataset) !== null && _a !== void 0 ? _a : {}; },
            describedBy: () => { var _a; return (_a = options.describedBy) !== null && _a !== void 0 ? _a : ''; },
            execute: async (args) => {
                const w1 = _ipylab__WEBPACK_IMPORTED_MODULE_1__.IpylabModel.app.shell.currentWidget;
                const connection_id = w1
                    ? _ipylab__WEBPACK_IMPORTED_MODULE_1__.IpylabModel.ConnectionModel.get_id(w1, true)
                    : '';
                const payload = { id, args, connection_id };
                return await this.scheduleOperation('execute', payload, 'object');
            },
            icon: icon,
            iconClass: () => { var _a; return (_a = options.iconClass) !== null && _a !== void 0 ? _a : ''; },
            iconLabel: () => { var _a; return (_a = options.iconLabel) !== null && _a !== void 0 ? _a : ''; },
            isEnabled: () => { var _a; return (_a = options.isEnabled) !== null && _a !== void 0 ? _a : true; },
            isToggleable,
            isToggled,
            isVisible: () => { var _a; return (_a = options.isVisible) !== null && _a !== void 0 ? _a : true; },
            label: () => options.label,
            mnemonic: () => { var _a; return Number((_a = options.mnemonic) !== null && _a !== void 0 ? _a : -1); },
            usage: () => { var _a; return (_a = options.usage) !== null && _a !== void 0 ? _a : ''; }
        };
        const command = this.base.addCommand(id, mappings);
        return new CommandLink(command, id, options, mappings);
    }
}
class CommandLink extends _observable_disposable__WEBPACK_IMPORTED_MODULE_2__.ObservableDisposable {
    constructor(command, id = '', options, mappings) {
        super();
        this.command = command;
        this.id = id;
        this.config = options;
        this.mappings = mappings;
    }
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this.command.dispose();
        super.dispose();
    }
}


/***/ }),

/***/ "./lib/widgets/connection.js":
/*!***********************************!*\
  !*** ./lib/widgets/connection.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ConnectionModel: () => (/* binding */ ConnectionModel),
/* harmony export */   ShellConnectionModel: () => (/* binding */ ShellConnectionModel)
/* harmony export */ });
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
// Copyright (c) Jupyter Development Team.
// Distributed under the terms of the Modified BSD License.




/**
 * ConnectionModel provides a connection to an object using a unique 'connection_id'.
 *
 * The object to be referenced must first be registered static method
 * `ConnectionModel.registerConnection`.
 */
class ConnectionModel extends _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel {
    constructor() {
        super(...arguments);
        this.isConnectionModel = true;
    }
    /**
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: 'ConnectionModel' };
    }
    async ipylabInit(base = null) {
        this.connection_id = this.get('connection_id');
        base = await this.getObject();
        if (!base) {
            this.close();
            return;
        }
        base.disposed.connect(this._base_disposed, this);
        await super.ipylabInit(base);
    }
    _base_disposed() {
        this.set('auto_dispose', false);
        this.close(false);
    }
    close(comm_closed = false) {
        var _a, _b, _c, _d, _e, _f;
        (_a = Private.pending.get(this.connection_id)) === null || _a === void 0 ? void 0 : _a.reject('closing');
        Private.pending.delete(this.connection_id);
        (_c = (_b = this.base) === null || _b === void 0 ? void 0 : _b.disposed) === null || _c === void 0 ? void 0 : _c.disconnect(this._base_disposed, this);
        if ((_e = (_d = this.base) === null || _d === void 0 ? void 0 : _d.ipylabDisposeOnClose) !== null && _e !== void 0 ? _e : this.get('auto_dispose')) {
            this.set('auto_dispose', false);
            (_f = this.base) === null || _f === void 0 ? void 0 : _f.dispose();
        }
        return super.close(comm_closed);
    }
    async getObject() {
        // This is async for overloading
        return Private.connections.get(this.connection_id);
    }
    /**
     * Keep a reference to an object so it can be found from the backend.
     * Also keeps a reverse mapping for the last registered connection_id of the object
     * see: `IpylabModel.get_id`
  
     * @param obj
     */
    static registerConnection(connection_id, obj) {
        if (!connection_id) {
            throw new Error('`connection_id` not provided!');
        }
        if (typeof obj !== 'object') {
            throw new Error(`An object is required but got a '${typeof obj}'`);
        }
        while (obj === null || obj === void 0 ? void 0 : obj.isConnectionModel) {
            obj = obj.base;
        }
        if (obj === null || obj === void 0 ? void 0 : obj.isDisposed) {
            throw new Error('object is disposed');
        }
        if (Private.connections.has(connection_id) &&
            Private.connections.get(connection_id) !== obj) {
            throw new Error(`Another object is already registered for connection_id: ${connection_id}`);
        }
        ConnectionModel.ensureObservableDisposable(obj);
        obj.disposed.connect(() => {
            Private.connections.delete(connection_id);
            Private.connections_rev.delete(obj);
        });
        Private.connections.set(connection_id, obj);
        Private.connections_rev.set(obj, connection_id);
        if (Private.pending.has(connection_id)) {
            Private.pending.get(connection_id).resolve(null);
            Private.pending.delete(connection_id);
        }
        return obj;
    }
    /**
     * Modify the object to make it usable as an IObservableDisposable.
     * @param obj The object to modify.
     * @returns
     */
    static ensureObservableDisposable(obj) {
        if (typeof obj !== 'object') {
            throw new Error(`An object is required but got ${typeof obj} `);
        }
        if (obj.disposed) {
            // Assume obj provides an IObservableDisposable interface.
            return;
        }
        const args = { enumerable: false, configurable: true, writable: false };
        if (!obj.dispose) {
            Object.defineProperties(obj, {
                dispose: { value: () => null, ...args },
                ipylabDisposeOnClose: { value: true, ...args }
            });
        }
        const disposed = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal(obj);
        const dispose_ = obj.dispose.bind(obj);
        const dispose = () => {
            if (obj.isDisposed) {
                return;
            }
            dispose_();
            disposed.emit(null);
            _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal.clearData(obj);
            if (!obj.isDisposed) {
                obj.isDisposed = true;
            }
        };
        Object.defineProperties(obj, {
            dispose: { value: dispose.bind(obj), ...args },
            disposed: { value: disposed, ...args }
        });
    }
    static get_id(obj, register = false) {
        if (register && !Private.connections_rev.has(obj)) {
            const cls = obj instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget &&
                obj.id &&
                ConnectionModel.ShellModel.getLuminoWidgetFromShell(obj.id)
                ? 'ShellConnection'
                : 'Connection';
            const connection_id = ConnectionModel.new_id(cls);
            ConnectionModel.registerConnection(connection_id, obj);
        }
        return Private.connections_rev.get(obj);
    }
    static getConnection(connection_id) {
        return Private.connections.get(connection_id);
    }
    /**
     * Get the session associated with the lumino widget if it has one.
     */
    static async getSession(widget) {
        var _a, _b, _c, _d;
        const path = (_a = widget === null || widget === void 0 ? void 0 : widget.ipylabSettings) === null || _a === void 0 ? void 0 : _a.vpath;
        if (path) {
            return await ConnectionModel.sessionManager.findByPath(path);
        }
        return (_d = (_c = (_b = widget === null || widget === void 0 ? void 0 : widget.sessionContext) === null || _b === void 0 ? void 0 : _b.session) === null || _c === void 0 ? void 0 : _c.model) !== null && _d !== void 0 ? _d : {};
    }
    static new_id(cls) {
        const _PREFIX = 'ipylab-';
        const _SEP = '|';
        return `${_PREFIX}${cls}${_SEP}${_lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.UUID.uuid4()}`;
    }
}
/**
 * A connection to widgets in the Shell.
 */
class ShellConnectionModel extends ConnectionModel {
    /*
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: 'ShellConnectionModel' };
    }
    async getObject() {
        var _a;
        if (!Private.connections.has(this.connection_id) &&
            !Private.pending.has(this.connection_id)) {
            const pending = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_0__.PromiseDelegate();
            Private.pending.set(this.connection_id, pending);
            _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.tracker.restored.then(() => {
                if (!Private.connections.has(this.connection_id)) {
                    setTimeout(() => pending.resolve(null), 10000);
                }
            });
        }
        await ((_a = Private.pending.get(this.connection_id)) === null || _a === void 0 ? void 0 : _a.promise);
        return Private.connections.get(this.connection_id);
    }
    async operation(op, payload) {
        switch (op) {
            case 'activate':
                return _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.app.shell.activateById(this.base.id);
            case 'getSession':
                return ShellConnectionModel.getSession(this.base);
            default:
                return await super.operation(op, payload);
        }
    }
}
_ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.ConnectionModel = ConnectionModel;
/**
 * A namespace for private data
 */
var Private;
(function (Private) {
    Private.pending = new Map();
    Private.connections = new Map();
    Private.connections_rev = new Map();
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/widgets/cssstylesheet.js":
/*!**************************************!*\
  !*** ./lib/widgets/cssstylesheet.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CSSStyleSheetModel: () => (/* binding */ CSSStyleSheetModel)
/* harmony export */ });
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.

/**
 * The model for a CSSStyleSheet.
 */
class CSSStyleSheetModel extends _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel {
    constructor() {
        super(...arguments);
        this.sheet = new CSSStyleSheet();
    }
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'CSSStyleSheetModel'
        };
    }
    async ipylabInit() {
        document.adoptedStyleSheets = [...document.adoptedStyleSheets, this.sheet];
        await super.ipylabInit(this.sheet);
    }
    close(comm_closed) {
        document.adoptedStyleSheets = document.adoptedStyleSheets.filter(item => item !== this.sheet);
        return super.close(comm_closed);
    }
    async operation(op, payload) {
        switch (op) {
            case 'deleteRule':
                this.sheet.deleteRule(payload.index);
                return this._listCSSRules();
            case 'insertRule':
                this.sheet.insertRule(payload.rule, payload.index);
                return this._listCSSRules();
            case 'replace':
                await this.sheet.replace(payload.text);
                return this._listCSSRules();
            case 'listCSSRules':
                return this._listCSSRules();
            default:
                return await super.operation(op, payload);
        }
    }
    /**
     * Return the text of the css rules.
     */
    _listCSSRules() {
        const rules = [];
        for (const rule of this.sheet.cssRules) {
            rules.push(rule.cssText);
        }
        return rules;
    }
    /**
     * Set global css variables.
     */
    setVariables(variables) {
        for (const name in variables) {
            document.documentElement.style.setProperty(name, variables[name]);
        }
        const list = {};
        const allVariables = this.listVariables();
        for (const name in variables) {
            list[name] = allVariables[name];
        }
        return list;
    }
    /**
     * Get a list of the global css variables.
     */
    listVariables() {
        const list = {};
        if ('computedStyleMap' in document.documentElement) {
            // Chrome
            const styles = document.documentElement.computedStyleMap();
            styles.forEach((val, key) => {
                if (key.startsWith('--')) {
                    list[key] = val.toString();
                }
            });
        }
        else {
            // Firefox
            const styles = getComputedStyle(document.documentElement);
            for (let i = 0; i < styles.length; i++) {
                const propertyName = styles[i];
                if (propertyName.startsWith('--')) {
                    const value = styles.getPropertyValue(propertyName);
                    list[propertyName] = value;
                }
            }
        }
        return list;
    }
}


/***/ }),

/***/ "./lib/widgets/dialog.js":
/*!*******************************!*\
  !*** ./lib/widgets/dialog.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DialogModel: () => (/* binding */ DialogModel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.



class DialogModel extends _ipylab__WEBPACK_IMPORTED_MODULE_2__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: 'DialogModel' };
    }
    async operation(op, payload) {
        function _get_result(result) {
            if (result.value === null) {
                throw new Error('Cancelled');
            }
            return result.value;
        }
        let result;
        switch (op) {
            case 'showDialog':
                result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showDialog)(payload);
                return { value: result.button.accept, isChecked: result.isChecked };
            case 'getBoolean':
                return await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getBoolean(payload).then(_get_result);
            case 'getItem':
                return await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getItem(payload).then(_get_result);
            case 'getNumber':
                return await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getNumber(payload).then(_get_result);
            case 'getText':
                return await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getText(payload).then(_get_result);
            case 'getPassword':
                return await _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.InputDialog.getPassword(payload).then(_get_result);
            case 'showErrorMessage':
                return await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)(payload.title, payload.error, payload.buttons);
            case 'getOpenFiles':
                payload.manager = _ipylab__WEBPACK_IMPORTED_MODULE_2__.IpylabModel.defaultBrowser.model.manager;
                return await _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getOpenFiles(payload).then(_get_result);
            case 'getExistingDirectory':
                payload.manager = _ipylab__WEBPACK_IMPORTED_MODULE_2__.IpylabModel.defaultBrowser.model.manager;
                return await _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getExistingDirectory(payload).then(_get_result);
            default:
                return await super.operation(op, payload);
        }
    }
}


/***/ }),

/***/ "./lib/widgets/frontend.js":
/*!*********************************!*\
  !*** ./lib/widgets/frontend.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JupyterFrontEndModel: () => (/* binding */ JupyterFrontEndModel)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/jupyterlab-manager */ "webpack/sharing/consume/default/@jupyter-widgets/jupyterlab-manager");
/* harmony import */ var _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.




const VPATH = '_vpath';
/**
 * JupyterFrontEndModel (JFEM) is a SINGLETON per kernel.
 */
class JupyterFrontEndModel extends _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: 'JupyterFrontEndModel' };
    }
    initialize(attributes, options) {
        super.initialize(attributes, options);
        this.kernelId = this.kernel.id;
        Private.jfems.set(this.kernel.id, this);
    }
    async ipylabInit(base = null) {
        const vpath = await JFEM.getVpath(this.kernelId);
        this.set(VPATH, vpath);
        this.set('version', JFEM.app.version);
        this.set('per_kernel_widget_manager_detected', JFEM.PER_KERNEL_WM);
        await super.ipylabInit(base);
        if (!Private.vpathTojfem.has(vpath)) {
            Private.vpathTojfem.set(vpath, new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__.PromiseDelegate());
        }
        Private.vpathTojfem.get(vpath).resolve(this);
    }
    close(comm_closed) {
        Private.jfems.delete(this.kernelId);
        Private.vpathTojfem.delete(this.get(VPATH));
        return super.close(comm_closed);
    }
    async operation(op, payload) {
        var _a;
        switch (op) {
            case 'evaluate':
                return await JFEM.getModelByVpath(payload.vpath).then(jfem => jfem.scheduleOperation('evaluate', payload, 'object'));
            case 'startIyplabKernel':
                return await JFEM.startIpylabKernel((_a = payload.restart) !== null && _a !== void 0 ? _a : false);
            case 'shutdownKernel':
                if (payload.vpath) {
                    if (Private.vpathTojfem.has(payload.vpath)) {
                        await JFEM.getModelByVpath(payload.vpath).then(jfem => jfem.kernel.shutdown());
                    }
                }
                else {
                    this.kernel.shutdown();
                }
                return null;
            default:
                return await super.operation(op, payload);
        }
    }
    /**
     * Get the vpath for given a kernel id.
     */
    static async getVpath(kernelId) {
        if (Private.kernelIdToVpath.has(kernelId)) {
            return Private.kernelIdToVpath.get(kernelId);
        }
        for (const session of JFEM.sessionManager.running()) {
            if (session.kernel.id === kernelId) {
                Private.kernelIdToVpath.set(kernelId, session.path);
                return session.path;
            }
        }
        await JFEM.sessionManager.refreshRunning();
        for (const session of JFEM.sessionManager.running()) {
            if (session.kernel.id === kernelId) {
                Private.kernelIdToVpath.set(kernelId, session.path);
                return session.path;
            }
        }
        throw new Error(`Failed to determine vpath for kernelId='${kernelId}'`);
    }
    /**
     * Get the JupyterFrontendModel for the vpath.
     * If the path doesn't exist, a new kernel will be started.
     * @param vpath The session path
     * @returns
     */
    static async getModelByVpath(vpath, preferredKernel = 'async') {
        if (!vpath || typeof vpath !== 'string') {
            throw new Error(`Invalid vpath ${vpath}`);
        }
        if (!Private.vpathTojfem.has(vpath)) {
            if (!JFEM.PER_KERNEL_WM) {
                throw new Error('A per-kernel KernelWidgetManager is required to start a new session!');
            }
            let kernel;
            Private.vpathTojfem.set(vpath, new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_2__.PromiseDelegate());
            await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.sessionManager.refreshRunning();
            const model = await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.sessionManager.findByPath(vpath);
            if (model) {
                kernel = _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.app.serviceManager.kernels.connectTo({
                    model: model.kernel
                });
            }
            else {
                const sessionContext = await JFEM.newSessionContext(vpath, preferredKernel);
                kernel = sessionContext.session.kernel;
            }
            Private.kernelIdToVpath.set(kernel.id, vpath);
            // Relies on per-kernel widget manager.
            const getManager = _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_0__.KernelWidgetManager.getManager;
            const widget_manager = await getManager(kernel);
            const code = 'import ipylab;ipylab.App()';
            if (!Private.jfems.has(kernel.id)) {
                widget_manager.kernel.requestExecute({ code }, true);
            }
        }
        return await new Promise((resolve, reject) => {
            const timeoutID = setTimeout(() => {
                var _a;
                const msg = `Failed to get a JupyterFrontendModel for vpath='${vpath}'`;
                (_a = Private.vpathTojfem.get(vpath)) === null || _a === void 0 ? void 0 : _a.reject(msg);
                Private.vpathTojfem.delete(vpath);
                reject(msg);
            }, 10000);
            Private.vpathTojfem.get(vpath).promise.then(jfem => {
                if (!jfem.commAvailable) {
                    jfem.close();
                    JupyterFrontEndModel.getModelByVpath(vpath, preferredKernel).then(jfem => {
                        clearTimeout(timeoutID);
                        resolve(jfem);
                    });
                }
                else {
                    clearTimeout(timeoutID);
                    resolve(jfem);
                }
            });
        });
    }
    /**
     * Create a new session context for vpath.
     *
     * This will automatically starting a new kernel if a session path matching
     * vpath isn't found.
     */
    static async newSessionContext(vpath, preferredKernel = 'async') {
        const sessionContext = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.SessionContext({
            sessionManager: _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.sessionManager,
            specsManager: _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.app.serviceManager.kernelspecs,
            path: vpath,
            name: vpath,
            type: 'console',
            kernelManager: _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.app.serviceManager.kernels,
            kernelPreference: { language: 'python', name: preferredKernel }
        });
        await sessionContext.initialize();
        if (!sessionContext.isReady) {
            await new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.SessionContextDialogs({
                translator: _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.translator
            }).selectKernel(sessionContext);
        }
        if (!sessionContext.isReady) {
            sessionContext.dispose();
            throw new Error('Cancelling because a kernel was not provided');
        }
        return sessionContext;
    }
    /**
     * Get the WidgetModel
     *
     * This depends on the PR requiring a per-kernel widget manager.
     *
     * @param model_id The model id
     * @returns WidgetModel
     */
    static async getWidgetModel(model_id) {
        const manager = await JFEM.getWidgetManager(model_id);
        return await manager.get_model(model_id);
    }
    /**
     * Get the WidgetManger searching all known kernels.
     *
     * @param model_id The widget model id
     * @returns
     */
    static async getWidgetManager(model_id, delays = [100, 5000]) {
        for (const sleepTime of delays) {
            for (const jfem of Private.jfems.values()) {
                if (jfem.widget_manager.has_model(model_id)) {
                    return jfem.widget_manager;
                }
            }
            await new Promise(resolve => setTimeout(resolve, sleepTime));
        }
        throw new Error(`Failed to locate the KernelWidgetManager for model_id='${model_id}'`);
    }
    /**
     *
     * @param restart Restart the kernel
     */
    static async startIpylabKernel(restart = false) {
        if (restart) {
            const model = await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.sessionManager.findByPath('ipylab');
            if (model) {
                await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.app.serviceManager.kernels.shutdown(model.kernel.id);
            }
        }
        await _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.JFEM.getModelByVpath('ipylab', 'async');
    }
}
_ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.JFEM = JupyterFrontEndModel;
const JFEM = JupyterFrontEndModel;
/**
 * A namespace for private data
 */
var Private;
(function (Private) {
    /**
     * A mapping of vpath to JupyterFrontEndModel.
     */
    Private.vpathTojfem = new Map();
    /**
     * A mapping of kernelId to vpath, possibly set before the model is created.
     */
    Private.kernelIdToVpath = new Map();
    /**
     * A mapping of kernelId to JupyterFrontEndModel.
     */
    Private.jfems = new Map();
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/widgets/icon.js":
/*!*****************************!*\
  !*** ./lib/widgets/icon.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IconModel: () => (/* binding */ IconModel),
/* harmony export */   IconView: () => (/* binding */ IconView)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.



class IconView extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetView {
    initialize(parameters) {
        super.initialize(parameters);
        this.iconElement = document.createElement('div');
        this.el.appendChild(this.iconElement);
        this.update();
    }
    update() {
        const { labIcon } = this.model;
        if (labIcon) {
            labIcon.render(this.iconElement, {
                props: { tag: 'div' }
            });
        }
    }
}
/**
 * The model for a title widget.
 */
class IconModel extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'IconModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_VERSION,
            _view_name: 'IconView',
            _view_module: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_NAME,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_VERSION
        };
    }
    /**
     * Initialize a LabIcon instance.
     *
     * @param attributes The base attributes.
     * @param options The initialization options.
     */
    initialize(attributes, options) {
        super.initialize(attributes, options);
        this.on('change:name change:svgstr', this.updateIcon);
        this.updateIcon();
    }
    get labIcon() {
        return this._labIcon;
    }
    /**
     * Update the LabIcon when model changes occur
     */
    updateIcon() {
        const name = this.get('name');
        const svgstr = this.get('svgstr');
        if (!this._labIcon || this._labIcon.name !== name) {
            this._labIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_1__.LabIcon({ name, svgstr });
        }
        this._labIcon.svgstr = svgstr;
        this.trigger('change');
    }
}


/***/ }),

/***/ "./lib/widgets/ipylab.js":
/*!*******************************!*\
  !*** ./lib/widgets/ipylab.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IpylabModel: () => (/* binding */ IpylabModel)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyter-widgets/jupyterlab-manager */ "webpack/sharing/consume/default/@jupyter-widgets/jupyterlab-manager");
/* harmony import */ var _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utils */ "./lib/utils.js");
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.









/**
 * Base model for Ipylab.
 *
 * Subclass as required but can also be used directly.
 */
class IpylabModel extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetModel {
    constructor() {
        super(...arguments);
        this._signalDisconnectors = new Map();
        this._pendingOperations = new Map();
        this.translator = IpylabModel.translator.load('jupyterlab');
    }
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'IpylabModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_7__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_7__.MODULE_VERSION,
            _view_name: null,
            _view_module: null,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_7__.MODULE_VERSION,
            _view_count: 0,
            _signal_dottednames: []
        };
    }
    initialize(attributes, options) {
        super.initialize(attributes, options);
        this.set('_ready', false);
        this.save_changes();
        this.on('msg:custom', this.onCustomMessage, this);
        IpylabModel.onKernelLost(this.kernel, this.onKernelLost, this);
        if (this.widget_manager.restoredStatus || !IpylabModel.PER_KERNEL_WM) {
            this._startIpylabInit();
        }
        else {
            // Defer ipylabInit until widget restoration is finished.
            this.widget_manager.restored.connect(this._startIpylabInit, this);
        }
    }
    _startIpylabInit() {
        this.widget_manager.restored.disconnect(this._startIpylabInit, this);
        this.widget_manager.get_model(this.model_id).then(() => this.ipylabInit());
    }
    /**
     * Finish initializing the model.
     * Overload this method as required.
     *
     * When overloading call:
     *  `await super.ipylabInit()`
     *
     * @param base override the base of the instance.
     */
    async ipylabInit(base = null) {
        var _a;
        if (!base) {
            let subpath;
            [base, subpath] = await this.toBaseAndSubpath(this.get('ipylab_base'), 'this');
            base = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj: base, subpath, nullIfMissing: true });
            if (!base) {
                this.ipylabSend({
                    error: `Invalid ipylab_base '${this.get('ipylab_base')}'!`
                });
                this.close();
            }
        }
        Object.defineProperty(this, 'base', {
            value: base,
            writable: false,
            configurable: true
        });
        this.listenTo(this, 'change:_signal_dottednames', this.update_signals);
        this.listenTo(this, 'change:_view_count', this.update_signals);
        if ((_a = this.get('_signal_dottednames')) === null || _a === void 0 ? void 0 : _a.length) {
            this.update_signals();
        }
        this.setReady();
    }
    /**
     * This is called once the object is ready by ipylabInit.
     * It can be overloaded, but shouldn't be called.
     */
    setReady() {
        this.set('_ready', true);
        this.save_changes();
    }
    onKernelLost() {
        this.close(true);
    }
    close(comm_closed) {
        this._pendingOperations.forEach(opDone => opDone.reject('Closed'));
        this._pendingOperations.clear();
        comm_closed = comm_closed || !this.commAvailable;
        this.set('_signal_dottednames', []);
        this.stopListening(this, 'change:_signal_dottednames', this.update_signals);
        this.stopListening(this, 'change:_view_count', this.update_signals);
        if (!comm_closed) {
            this.ipylabSend({ closed: true });
        }
        Object.defineProperty(this, 'base', { value: null });
        return super.close(true);
    }
    save_changes(callbacks) {
        if (this.commAvailable) {
            super.save_changes(callbacks);
        }
    }
    /**
     * Send a custom msg over the comm.
     */
    ipylabSend(content, callbacks, buffers) {
        try {
            content = JSON.stringify(content);
        }
        catch (_a) {
            if (content.transform === 'auto') {
                content.payload = {
                    connection_id: IpylabModel.ConnectionModel.get_id(content.payload, true)
                };
            }
            content = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.toJSONsubstituteCylic)(content);
        }
        this.send({ ipylab: content }, callbacks, buffers);
    }
    /**
     * Updates the signal connections based on the
     * `_signal_dottednames` trait.
     *
     * This method iterates through the dotted names of signals,
     * connects them to the corresponding objects (either views or the
     * base object), and manages the connection/disconnection of signals
     * to avoid memory leaks.
     *
     * It supports signals belonging to views by iterating over the views
     * and connecting the signal to each view. It also handles signals
     * belonging to the base object directly.
     *
     * The method maintains a set of active signal keys and disconnects
     * any previously connected signals that are no longer in the set of
     * active signals.
     */
    async update_signals() {
        const dottednames = this.get('_signal_dottednames');
        if (!dottednames.length && !this._signalDisconnectors.size) {
            return;
        }
        const keys = new Set();
        const views = this.views;
        for (const dottedname of dottednames) {
            // Support signals belonging to views
            if (views && dottedname.startsWith('views.')) {
                for (const id of Object.getOwnPropertyNames(views)) {
                    const view = await this.views[id];
                    keys.add(this._connectSignal(view, dottedname));
                }
            }
            else {
                keys.add(this._connectSignal(this.base, dottedname));
            }
        }
        // Check for old signals to disconnect
        this._signalDisconnectors.forEach((value, key) => {
            if (!keys.has(key)) {
                value();
                this._signalDisconnectors.delete(key);
            }
        });
    }
    _connectSignal(obj, dottedname) {
        const key = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.uniqueId)(obj) + dottedname;
        if (!this._signalDisconnectors.has(key)) {
            const subpath = dottedname.startsWith('views.')
                ? dottedname.slice(6)
                : dottedname;
            const signal = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj, subpath, nullIfMissing: true });
            if (signal instanceof _lumino_signaling__WEBPACK_IMPORTED_MODULE_5__.Signal) {
                const slot = (sender, args) => {
                    this.sendSignal({ dottedname, args });
                };
                this._signalDisconnectors.set(key, () => signal.disconnect(slot));
                signal.connect(slot);
            }
        }
        return key;
    }
    /**
     * Sends a signal to the Python backend.
     *
     * @param args - The arguments to send with the signal. Must be a JSON-serializable value.
     */
    sendSignal(args) {
        this.ipylabSend({ signal: args });
    }
    /**
     * Schedule an operation to be performed in Python.
     * This is a mirror of `Ipylab.operation` in Python.
     *
     * @param operation The name of the operation to perform in Python.
     * @param payload Payload to send to Python.
     * @param transform The type of transformation to apply on the returned result.
     */
    async scheduleOperation(operation, payload, transform) {
        const ipylab_FE = _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__.UUID.uuid4();
        // Create callbacks to be resolved when a custom message is received
        // with the key `ipylab_FE`.
        const opDone = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_4__.PromiseDelegate();
        this._pendingOperations.set(ipylab_FE, opDone);
        this.ipylabSend({ ipylab_FE, operation, payload });
        const result = await opDone.promise;
        return await this.transformObject(result, transform);
    }
    /**
     * Perform an operation and return the result.
     *
     * Overload as required.
     *
     * @param op Name of the operation.
     * @param payload Options relevant to the operation.
     * @returns Raw result of the operation.
     */
    async operation(op, payload) {
        switch (op) {
            case 'genericOperation':
                return await this.genericOperation(payload);
            default:
                // Each failed operation should throw an error if it is un-handled
                throw new Error(`genericOperation "${op}" not implemented!`);
        }
    }
    /**
     * Perform a generic operation and return the result.
     */
    async genericOperation(payload) {
        payload.obj = await this.getBase(payload.basename);
        switch (payload.genericOperation) {
            case 'executeMethod':
                return await (0,_utils__WEBPACK_IMPORTED_MODULE_8__.executeMethod)(payload);
            case 'getProperty':
                return await (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)(payload);
            case 'listProperties':
                payload.obj = await (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)(payload);
                return (0,_utils__WEBPACK_IMPORTED_MODULE_8__.listProperties)(payload);
            case 'setProperty':
                return (0,_utils__WEBPACK_IMPORTED_MODULE_8__.setNestedProperty)(payload);
            case 'updateProperty':
                return (0,_utils__WEBPACK_IMPORTED_MODULE_8__.updateProperty)(payload);
            default:
                throw new Error(`'${payload.methodName}' has not been implemented`);
        }
    }
    /**
     * Handles custom messages received from the Python backend.
     *
     * @param msg The message received from the backend.
     */
    onCustomMessage(msg) {
        if (msg.ipylab) {
            this._onBackendMessage(JSON.parse(msg.ipylab));
        }
    }
    /**
     * Handles messages received from the backend.
     *
     * This method processes messages from the Python backend, which can include:
     * - Results of operations requested by the frontend.
     * - Requests for operations to be performed by the frontend on behalf of the backend.
     * - Instructions to close the widget.
     *
     * @param content - The content of the message received from the backend.  The content
     *                  is expected to have one of the following properties: `ipylab_FE`, `ipylab_PY`, or `close`.
     *
     * If `content.ipylab_FE` is present:
     *   - Retrieves the corresponding pending operation.
     *   - Replaces parts of the widget based on the received keyword arguments and conversion flags.
     *   - Resolves or rejects the pending operation based on the success of the `replaceParts` method and the presence of an error in the content.
     *
     * If `content.ipylab_PY` is present:
     *   - Executes an operation requested by the Python backend using the `doOperationForPython` method.
     *
     * If `content.close` is present:
     *   - Closes the widget.
     */
    async _onBackendMessage(content) {
        var _a, _b;
        if (content.ipylab_FE) {
            // Result of an operation request sent to Python.
            const op = this._pendingOperations.get(content.ipylab_FE);
            const { kwgs, toLuminoWidget, toObject } = content;
            this._pendingOperations.delete(content.ipylab_FE);
            try {
                await this.replaceParts(kwgs, toLuminoWidget, toObject);
            }
            catch (e) {
                content.error = e;
            }
            if (op) {
                if (content.error) {
                    op.reject(new Error((_b = (_a = content.error) === null || _a === void 0 ? void 0 : _a.repr) !== null && _b !== void 0 ? _b : content.error));
                }
                else {
                    op.resolve(content.payload);
                }
            }
        }
        else if (content.ipylab_PY) {
            this.doOperationForPython(content);
        }
        else if (content.close) {
            this.close(true);
        }
    }
    /**
     * Executes a specified operation in Python, handles data transformation,
     * and sends the result back to the Python environment.
     *
     * @param content - An object containing the operation details,
     * including the operation name, Python object identifier,
     * transformation instructions, keyword arguments, and flags for
     * Lumino widget and object conversion.
     *
     * @remarks
     * This method orchestrates the execution of a Python operation,
     * potentially transforming the result before sending it back.
     * It also handles error reporting to the Python environment.
     *
     * The `content` object is expected to have the following properties:
     * - `operation`: The name of the operation to execute in Python.
     * - `ipylab_PY`: An identifier for the Python object associated with the operation.
     * - `transform`: Instructions for transforming the result object.
     * - `kwgs`: Keyword arguments to pass to the Python operation.
     * - `toLuminoWidget`: A flag indicating whether to convert objects to Lumino widgets.
     * - `toObject`: A flag indicating whether to convert objects to plain JavaScript objects.
     *
     * The method performs the following steps:
     * 1. Replaces parts of the keyword arguments based on `toLuminoWidget` and `toObject` flags.
     * 2. Executes the specified operation with the provided keyword arguments.
     * 3. Extracts the payload and buffers from the result object, if present.
     * 4. Transforms the result object using the provided transformation instructions.
     * 5. Sends the transformed payload back to the Python environment.
     * 6. If an error occurs during any of these steps, it sends an error message
     *    back to the Python environment and logs the error to the console.
     */
    async doOperationForPython(content) {
        var _a;
        const { operation, ipylab_PY, transform } = content;
        const { kwgs, toLuminoWidget, toObject } = content;
        try {
            await this.replaceParts(kwgs, toLuminoWidget, toObject);
            let obj, buffers;
            obj = await this.operation(operation, kwgs);
            if (obj === null || obj === void 0 ? void 0 : obj.payload) {
                buffers = obj.buffers;
                obj = obj.payload;
            }
            const payload = (_a = (await this.transformObject(obj, transform))) !== null && _a !== void 0 ? _a : null;
            this.ipylabSend({ ipylab_PY, operation, payload }, null, buffers);
        }
        catch (e) {
            this.ipylabSend({
                operation,
                ipylab_PY,
                error: `${e.message}`
            });
            console.error(e);
        }
    }
    /**
     * Replaces parts of a nested object with Lumino widgets or plain JavaScript objects.
     *
     * @param obj The object whose parts need to be replaced.
     * @param toLuminoWidget An array of subpaths within the object that should be replaced with Lumino widgets. Each subpath is a string representing the path to the property (e.g., 'a.b.c').
     * @param toObject An array of subpaths within the object that should be replaced with plain JavaScript objects.  Each subpath is a string representing the path to the property (e.g., 'a.b.c').
     *
     * @remarks
     * The `toLuminoWidget` replacements are performed first.
     * The `getNestedProperty` function is used to retrieve the value at the given subpath.
     * The `IpylabModel.toLuminoWidget` method is used to convert the value to a Lumino widget.
     * The `setNestedProperty` function is used to set the new widget value at the given subpath.
     *
     * For `toObject` replacements, the `toBaseAndSubpath` method is used to split the value into a base and subpath.
     * The `IpylabModel.toObject` method is then used to convert the value to a plain JavaScript object.
     * Finally, the `setNestedProperty` function is used to set the new object value at the given subpath.
     */
    async replaceParts(obj, toLuminoWidget, toObject) {
        if (toLuminoWidget instanceof Array) {
            // Replace values in kwgs with widgets
            for (const subpath of toLuminoWidget) {
                const value = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj, subpath });
                if (value) {
                    const lw = await IpylabModel.toLuminoWidget({ id: value });
                    (0,_utils__WEBPACK_IMPORTED_MODULE_8__.setNestedProperty)({ obj, subpath, value: lw });
                }
            }
        }
        if (toObject instanceof Array) {
            for (const subpath of toObject) {
                let base, value;
                value = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj, subpath });
                if (value) {
                    [base, value] = await this.toBaseAndSubpath(value);
                    value = await IpylabModel.toObject(base, value);
                    (0,_utils__WEBPACK_IMPORTED_MODULE_8__.setNestedProperty)({ obj, subpath, value });
                }
            }
        }
    }
    /**
     * Converts a value, which can be a string or an array, into a base and subpath.
     *
     * If the value is an array, the first element is treated as the basename and the second as the subpath.
     * If the value is a string, it's treated as the subpath, and a default basename is used.
     *
     * @param value The input value, which can be a string or an array of strings.
     * @param defaultBasename The default basename to use if the value is a string. Defaults to 'base'.
     * @returns A tuple containing the base (obtained from `this.getBase` using the basename) and the subpath.
     */
    async toBaseAndSubpath(value, defaultBasename = 'base') {
        let basename = defaultBasename;
        if (value instanceof Array) {
            [basename, value] = value;
        }
        const base = await this.getBase(basename);
        return [base, value !== null && value !== void 0 ? value : ''];
    }
    /**
     * Get the object referenced by basename.
     */
    async getBase(basename) {
        switch (basename) {
            case 'this':
                return this;
            case 'base':
                return this.base;
            case 'IpylabModel':
                return IpylabModel;
            case 'MainMenu':
                return _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__.MainMenu;
            default:
                return await IpylabModel.toObject(this, basename);
        }
    }
    /**
     * Transforms an object based on the specified transformation type.
     *
     * @param obj The object to transform.
     * @param args The transformation arguments. If a string, it's treated as the transformation type.
     *             If an object, it should contain a `transform` property specifying the transformation type,
     *             and other properties relevant to the specific transformation.
     * @returns A promise resolving to the transformed object.
     * @throws Error if an invalid transformation type is provided.
     */
    async transformObject(obj, args) {
        const transform = typeof args === 'string' ? args : args.transform;
        let result, func;
        switch (transform) {
            case 'auto':
                if (obj === null || obj === void 0 ? void 0 : obj.dispose) {
                    return {
                        connection_id: IpylabModel.ConnectionModel.get_id(obj, true)
                    };
                }
                if (typeof (obj === null || obj === void 0 ? void 0 : obj.iterator) === 'function') {
                    return Array.from(obj);
                }
                return await obj;
            case 'null':
                return null;
            case 'connection':
                if (args.connection_id) {
                    IpylabModel.ConnectionModel.registerConnection(args.connection_id, obj);
                }
                return {
                    connection_id: IpylabModel.ConnectionModel.get_id(obj, true)
                };
            case 'advanced':
                // expects args.mappings = {key:transform}
                result = new Object();
                for (const key of Object.keys(args.mappings)) {
                    const base = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj, subpath: key });
                    result[key] = await this.transformObject(base, args.mappings[key]);
                }
                return result;
            case 'function':
                func = (0,_utils__WEBPACK_IMPORTED_MODULE_8__.toFunction)(args.code).bind(this);
                if (func.constructor.name === 'AsyncFunction') {
                    return await func(obj, args);
                }
                return func(obj);
            case 'object':
                // 'object' is used by the frontend only.
                if (obj) {
                    try {
                        return await IpylabModel.toObject(null, obj);
                    }
                    catch (_a) {
                        return obj;
                    }
                }
                return obj;
            default:
                throw new Error(`Invalid return mode: '${transform}'`);
        }
    }
    get kernel() {
        return this.widget_manager.kernel;
    }
    get commAvailable() {
        var _a, _b;
        return (!((_a = this.kernel) === null || _a === void 0 ? void 0 : _a.isDisposed) &&
            this.comm &&
            !['dead', 'restarting'].includes((_b = this.kernel) === null || _b === void 0 ? void 0 : _b.status));
    }
    /**
     * Get or create a lumino widget.
     *
     * @param args: an object with 'id' and 'vpath'
     * args is updated as the object is located
     * @returns
     */
    static async toLuminoWidget({ connection_id = '', id = '', ipy_model = '' } = {}) {
        let widget;
        widget = IpylabModel.ConnectionModel.getConnection(connection_id);
        if (widget instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_6__.Widget) {
            return widget;
        }
        if (!ipy_model && id.slice(0, 10) === 'IPY_MODEL_') {
            ipy_model = id.slice(10).split(':', 1)[0];
        }
        if (ipy_model) {
            let model = await IpylabModel.JFEM.getWidgetModel(ipy_model);
            if (model.isConnectionModel) {
                model = model.base;
            }
            if (!model.get('_view_name')) {
                const name = model.get('_model_name');
                throw new Error(`Model '${name}' does not have a view!`);
            }
            const manager = model.widget_manager;
            widget = (await manager.create_view(model, {})).luminoWidget;
            IpylabModel.onKernelLost(manager.kernel, widget.dispose, widget);
        }
        if (!(widget instanceof _lumino_widgets__WEBPACK_IMPORTED_MODULE_6__.Widget)) {
            throw new Error(`Unable to create a luminoWidget connection_id='${connection_id}' id='${id}' ipy_model='${ipy_model}`);
        }
        return widget;
    }
    /**
     * Converts a value to an object, handling special cases for strings starting with 'IPY_MODEL_'.
     *
     * If the value is a string, it checks if it starts with 'IPY_MODEL_'. If so, it extracts the model ID and subpath,
     * retrieves the widget model using `IpylabModel.JFEM.getWidgetModel`, and resolves nested properties using `getNestedProperty`.
     * If the value is not a string, it throws an error.
     *
     * @param obj The initial object to traverse, can be a widget model.
     * @param value The value to convert to an object. If it's a string starting with 'IPY_MODEL_', it's treated as a reference to a widget model and a subpath.
     * @param nullIfMissing Optional. If true, returns null if the nested property is missing. Defaults to false.
     * @returns A promise that resolves to the object or nested property.
     * @throws Error if the value is not a string.
     */
    static async toObject(obj, value, nullIfMissing = false) {
        if (typeof value === 'string') {
            let subpath = value;
            if (value.slice(0, 10) === 'IPY_MODEL_') {
                let model_id;
                [model_id, subpath] = value.slice(10).split('.', 2);
                obj = await IpylabModel.JFEM.getWidgetModel(model_id);
                if (obj.isConnectionModel) {
                    obj = obj.base;
                }
            }
            subpath = subpath !== null && subpath !== void 0 ? subpath : '';
            return await (0,_utils__WEBPACK_IMPORTED_MODULE_8__.getNestedProperty)({ obj, subpath, nullIfMissing });
        }
        throw new Error(`Cannot convert this value to an object: ${value}`);
    }
    /**
     * Will call `onKernelLost` when the kernel is dead or restarted.
     * Only required for non PER_KERNEL_WM
     */
    static onKernelLost(kernel, onKernelLost, thisArg) {
        if (IpylabModel.PER_KERNEL_WM) {
            // The model and view will now close as needed in ipywidgets.
            return;
        }
        if (!Private.kernelLostCallbacks.has(kernel)) {
            Private.kernelLostCallbacks.set(kernel, new Set());
            kernel.statusChanged.connect(_onKernelStatusChanged);
        }
        Private.kernelLostCallbacks.get(kernel).add([onKernelLost, thisArg]);
    }
    static get sessionManager() {
        return IpylabModel.app.serviceManager.sessions;
    }
}
IpylabModel.tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.WidgetTracker({ namespace: 'ipylab' });
IpylabModel.Notification = _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.Notification;
IpylabModel.PER_KERNEL_WM = Boolean(_jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1__.KernelWidgetManager === null || _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1__.KernelWidgetManager === void 0 ? void 0 : _jupyter_widgets_jupyterlab_manager__WEBPACK_IMPORTED_MODULE_1__.KernelWidgetManager.getManager);
/**
 * React to changes to the kernel status.
 */
function _onKernelStatusChanged(kernel) {
    if ([
        'dead',
        'starting',
        'restarting',
        'autorestarting',
        'terminating'
    ].includes(kernel.status)) {
        _kernelLost(kernel);
    }
}
function _kernelLost(kernel) {
    var _a, _b;
    if (!Private.kernelLostCallbacks.has(kernel)) {
        return;
    }
    (_a = Private.kernelLostCallbacks.get(kernel)) === null || _a === void 0 ? void 0 : _a.forEach(cb => cb[0].bind(cb[1])());
    (_b = Private.kernelLostCallbacks.get(kernel)) === null || _b === void 0 ? void 0 : _b.clear();
    if (kernel.isDisposed) {
        Private.kernelLostCallbacks.delete(kernel);
        kernel.statusChanged.disconnect(_kernelLost);
    }
}
/**
 * A namespace for private data
 */
var Private;
(function (Private) {
    Private.kernelLostCallbacks = new Map();
})(Private || (Private = {}));


/***/ }),

/***/ "./lib/widgets/notification.js":
/*!*************************************!*\
  !*** ./lib/widgets/notification.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NotificationManagerModel: () => (/* binding */ NotificationManagerModel)
/* harmony export */ });
/* harmony import */ var _observable_disposable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../observable_disposable */ "./lib/observable_disposable.js");
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.


/**
 * The model for a notification.
 */
class NotificationManagerModel extends _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'NotificationManagerModel'
        };
    }
    async operation(op, payload) {
        switch (op) {
            case 'update':
                return this.base.update(payload.args);
            case 'notification':
                return this.notification(payload);
            case 'createAction':
                return this.createAction(payload);
            default:
                return await super.operation(op, payload);
        }
    }
    notification(payload) {
        const { message, type, options } = payload;
        const id = this.base.notify(message, type, options);
        return new NotifyLink(id);
    }
    createAction(payload) {
        const action = { ...payload };
        const connection_id = action.connection_id;
        action.callback = (event) => {
            if (action.keep_open) {
                event.preventDefault();
            }
            return this.scheduleOperation('action_callback', { connection_id }, 'auto');
        };
        return action;
    }
}
/**
 * A small object to keep track of a notification in the notification manager by its id.
 *
 * It will dispose itself once the manager no longer 'has' the id registered.
 */
class NotifyLink extends _observable_disposable__WEBPACK_IMPORTED_MODULE_1__.ObservableDisposable {
    constructor(id = '') {
        super();
        this.id = id;
        this.id = id;
        this.manager.changed.connect(this._check_exists, this);
    }
    get manager() {
        return _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel.Notification.manager;
    }
    _check_exists() {
        if (!this.manager.has(this.id)) {
            this.dispose();
        }
    }
    dispose() {
        if (this.isDisposed) {
            return;
        }
        this.manager.changed.disconnect(this._check_exists, this);
        _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel.Notification.manager.dismiss(this.id);
        super.dispose();
    }
}


/***/ }),

/***/ "./lib/widgets/panel.js":
/*!******************************!*\
  !*** ./lib/widgets/panel.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PanelModel: () => (/* binding */ PanelModel),
/* harmony export */   PanelView: () => (/* binding */ PanelView)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyter-widgets/controls */ "webpack/sharing/consume/default/@jupyter-widgets/controls");
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.



/**
 * The model for a panel.
 */
class PanelModel extends _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1__.BoxModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'PanelModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_VERSION,
            _view_name: 'PanelView',
            _view_module: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_NAME,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_2__.MODULE_VERSION
        };
    }
}
PanelModel.serializers = {
    ..._jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1__.BoxModel.serializers,
    title: { deserialize: _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.unpack_models }
};
/**
 * The view for a Panel.
 */
class PanelView extends _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_1__.BoxView {
    initialize(parameters) {
        super.initialize(parameters);
        this.listenTo(this.model.get('title'), 'change', this.update_title);
        this.luminoWidget.removeClass('widget-box');
        this.luminoWidget.removeClass('jupyter-widgets');
        this.luminoWidget.addClass('ipylab-Panel');
        this.update_title();
    }
    update_title() {
        const title = this.model.get('title');
        title.update_title(this.luminoWidget.title);
    }
}


/***/ }),

/***/ "./lib/widgets/resize_box.js":
/*!***********************************!*\
  !*** ./lib/widgets/resize_box.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ResizeBoxModel: () => (/* binding */ ResizeBoxModel),
/* harmony export */   ResizeBoxView: () => (/* binding */ ResizeBoxView)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/controls */ "webpack/sharing/consume/default/@jupyter-widgets/controls");
/* harmony import */ var _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.


/**
 * The model for a Resizeable box.
 */
class ResizeBoxModel extends _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__.BoxModel {
    constructor() {
        super(...arguments);
        this._resizing = false;
    }
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'ResizeBoxModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_VERSION,
            _view_name: 'ResizeBoxView',
            _view_module: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_NAME,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_VERSION
        };
    }
}
/**
 * The view for a Resizeable box.
 */
class ResizeBoxView extends _jupyter_widgets_controls__WEBPACK_IMPORTED_MODULE_0__.BoxView {
    constructor() {
        super(...arguments);
        this._resizing = false;
    }
    initialize(parameters) {
        super.initialize(parameters);
        this.luminoWidget.removeClass('widget-box');
        this.luminoWidget.removeClass('jupyter-widgets');
        this.luminoWidget.addClass('ipylab-ResizeBox');
        this.resize();
        this.sizeObserver = new ResizeObserver(() => {
            if (!this.model._resizing && !this._resizing) {
                const clientWidth = this.el.clientWidth;
                const clientHeight = this.el.clientHeight;
                const width = this.el.style.width;
                const height = this.el.style.height;
                try {
                    this.model._resizing = true;
                    this._resizing = true;
                    if (clientWidth && clientHeight) {
                        this.model.set('size', [clientWidth, clientHeight]);
                    }
                    if (width && height) {
                        this.model.set('width_height', [width, height]);
                    }
                    if ((width && height) || (clientWidth && clientHeight)) {
                        this.model.save_changes();
                    }
                }
                finally {
                    this._resizing = false;
                    this.model._resizing = false;
                }
                if (!width && !height) {
                    this.resize();
                }
            }
        });
        this.sizeObserver.observe(this.el);
        this.listenTo(this.model, 'change:width_height', this.resize);
    }
    resize() {
        var _a;
        if (this._resizing) {
            return;
        }
        const [width, height] = (_a = this.model.get('width_height')) !== null && _a !== void 0 ? _a : [null, null];
        if (width && height) {
            this._resizing = true;
            this.el.style.width = width;
            this.el.style.height = height;
            this._resizing = false;
        }
    }
    remove() {
        var _a;
        (_a = this === null || this === void 0 ? void 0 : this.sizeObserver) === null || _a === void 0 ? void 0 : _a.disconnect();
        this.stopListening(this.model, 'change:size', this.resize);
        super.remove();
    }
}


/***/ }),

/***/ "./lib/widgets/sessions.js":
/*!*********************************!*\
  !*** ./lib/widgets/sessions.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SessionManagerModel: () => (/* binding */ SessionManagerModel)
/* harmony export */ });
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.
// SessionManager exposes `app.serviceManager.sessions` to user python kernel

/**
 * The model for a Session Manager
 */
class SessionManagerModel extends _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: SessionManagerModel };
    }
    async operation(op, payload) {
        switch (op) {
            case 'getCurrentSession':
                return await SessionManagerModel.ConnectionModel.getSession(_ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel.labShell.currentWidget);
            case 'getRunning':
                if (payload.refresh) {
                    await _ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel.sessionManager.refreshRunning();
                }
                return Array.from(_ipylab__WEBPACK_IMPORTED_MODULE_0__.IpylabModel.sessionManager.running());
            default:
                return await super.operation(op, payload);
        }
    }
}


/***/ }),

/***/ "./lib/widgets/shell.js":
/*!******************************!*\
  !*** ./lib/widgets/shell.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ShellModel: () => (/* binding */ ShellModel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.



const AREAS = [
    'main',
    'left',
    'right',
    'header',
    'top',
    'menu',
    'bottom'
];
class ShellModel extends _ipylab__WEBPACK_IMPORTED_MODULE_2__.IpylabModel {
    /**
     * The default attributes.
     */
    defaults() {
        return { ...super.defaults(), _model_name: 'ShellModel' };
    }
    setReady() {
        this.base.currentChanged.connect(this._currentChanged, this);
        super.setReady();
    }
    _currentChanged() {
        var _a;
        const id = (_a = this.base.currentWidget) === null || _a === void 0 ? void 0 : _a.id;
        if (id && id !== this.get('current_widget_id')) {
            this.set('current_widget_id', id);
            this.save_changes();
        }
    }
    close(comm_closed) {
        this.base.currentChanged.disconnect(this._currentChanged, this);
        return super.close(comm_closed);
    }
    async operation(op, payload) {
        switch (op) {
            case 'addToShell':
                return await ShellModel.addToShell(payload.args);
            case 'getWidget':
                if (!payload.id) {
                    return this.base.currentWidget;
                }
                return ShellModel.getLuminoWidgetFromShell(payload.id);
            case 'getWidgetIds':
                return ShellModel.listWidgetIds();
            default:
                return await super.operation(op, payload);
        }
    }
    /**
     * Provided for IpylabModel.tracker for restoring widgets to the shell.
     * @param args `ipylabSettings` in 'addToShell'
     */
    static async restoreToShell(args) {
        const sessions = ShellModel.app.serviceManager.sessions;
        if (!args.evaluate && !(await sessions.findByPath(args.vpath))) {
            // Don't create a kernel if a model doesn't exist.
            return;
        }
        await ShellModel.JFEM.getModelByVpath(args.vpath);
        await new Promise(resolve => {
            setTimeout(resolve, 10000);
            ShellModel.addToShell(args).then(resolve, e => {
                resolve(null);
                if (args.evaluate) {
                    throw e;
                }
            });
        });
    }
    /**
     * Add a widget to the application shell.
     *
     * This function can handle ipywidgets and native Widgets and  be used to
     * move widgets about the shell.
     *
     * Ipywidgets are added to a tracker enabling restoration from a running
     * kernel such as page refreshing and switching workspaces.
     *
     * Generative widget creation is supported with 'evaluate' using the same
     * code as 'evalute'. The evaluated code MUST return a widget with a view
     * to be valid.
     *
     * @param args An object with area, options, connection_id, id, vpath & evaluate.
     */
    static async addToShell(args) {
        let widget;
        try {
            widget = await ShellModel.toLuminoWidget(args);
            // Create a new lumino widget
        }
        catch (e) {
            if (args.evaluate) {
                // Evaluate code in python to get a panel and then add it to the shell.
                const jfem = await ShellModel.JFEM.getModelByVpath(args.vpath);
                return await jfem.scheduleOperation('shell_eval', args, 'object');
            }
            else {
                throw e;
            }
        }
        args.connection_id =
            args.connection_id ||
                ShellModel.ConnectionModel.new_id('ShellConnection');
        if (args.asMainArea && !(widget instanceof _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget)) {
            widget.addClass('ipylab-MainArea');
            const w = (widget = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget({ content: widget }));
            w.toolbar.dispose();
            w.contentHeader.dispose();
            w.id = args.connection_id;
        }
        ShellModel.ConnectionModel.registerConnection(args.connection_id, widget);
        widget.id = widget.id || args.connection_id || _lumino_coreutils__WEBPACK_IMPORTED_MODULE_1__.UUID.uuid4();
        ShellModel.app.shell.add(widget, args.area || 'main', args.options);
        // Register widgets originating from IpyWidgets
        if (args.ipy_model) {
            if (!ShellModel.tracker.has(widget)) {
                widget.ipylabSettings = args;
                ShellModel.tracker.add(widget);
            }
            else {
                widget.ipylabSettings.area = args.area;
                widget.ipylabSettings.options = args.options;
                ShellModel.tracker.save(widget);
            }
        }
        return widget;
    }
    /**
     * Get the lumino widget from the shell using its id.
     *
     * @param id
     */
    static getLuminoWidgetFromShell(id) {
        for (const area of AREAS) {
            for (const widget of ShellModel.labShell.widgets(area)) {
                if (widget.id === id) {
                    return widget;
                }
            }
        }
    }
    /**
     * Get mapping of area to array widget ids for all areas.
     */
    static listWidgetIds() {
        const data = Object.create(null);
        for (const area of AREAS) {
            const items = [];
            data[area] = items;
            for (const widget of ShellModel.labShell.widgets(area)) {
                items.push(widget.id);
            }
        }
        return data;
    }
}
_ipylab__WEBPACK_IMPORTED_MODULE_2__.IpylabModel.ShellModel = ShellModel;


/***/ }),

/***/ "./lib/widgets/simple_output.js":
/*!**************************************!*\
  !*** ./lib/widgets/simple_output.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SimpleOutputModel: () => (/* binding */ SimpleOutputModel),
/* harmony export */   SimpleOutputView: () => (/* binding */ SimpleOutputView)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/outputarea */ "webpack/sharing/consume/default/@jupyterlab/outputarea");
/* harmony import */ var _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ipylab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./ipylab */ "./lib/widgets/ipylab.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.




class IpylabOutputAreaModel extends _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1__.OutputAreaModel {
    constructor() {
        super(...arguments);
        this._continuousCount = 0;
        this.maxContinuous = 100;
    }
    /**
     * Whether a new value should be consolidated with the previous output.
     *
     * This will only be called if the minimal criteria of both being stream
     * messages of the same type.
     */
    shouldCombine(options) {
        if (options.value.name === 'stdout' &&
            this._continuousCount < this.maxContinuous) {
            this._continuousCount++;
            return true;
        }
        else {
            this._continuousCount = 0;
        }
        return false;
    }
    /**
     * Remove oldest outputs to the length limit.
     */
    removeOldest(maxLength) {
        if (this.list.length > maxLength) {
            this.list.removeRange(0, this.list.length - maxLength);
        }
    }
}
/**
 * The model for a panel.
 */
class SimpleOutputModel extends _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel {
    constructor() {
        super(...arguments);
        this._maxOutputs = 100;
        this.outputAreaModel = new IpylabOutputAreaModel({ trusted: true });
    }
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'SimpleOutputModel',
            _view_name: 'SimpleOutputView'
        };
    }
    setReady() {
        this.on('change:max_continuous_streams', this.configure, this);
        this.on('change:max_outputs', this.configure, this);
        this.configure();
        this.outputAreaModel.changed.connect(this._outputAreaModelChange, this);
        super.setReady();
    }
    async onCustomMessage(msg) {
        if (msg.add) {
            this.add(msg.add, msg.clear);
        }
        else {
            super.onCustomMessage(msg);
        }
    }
    async operation(op, payload) {
        switch (op) {
            case 'setOutputs':
                return await this.setOutputs(payload);
            default:
                return await super.operation(op, payload);
        }
    }
    configure() {
        this._maxOutputs = this.get('max_outputs');
        this.outputAreaModel.maxContinuous = this.get('max_continuous_streams');
    }
    _outputAreaModelChange() {
        const length = this.outputAreaModel.length;
        if (this.outputAreaModel.length > this._maxOutputs) {
            this.outputAreaModel.removeOldest(this._maxOutputs);
            return;
        }
        if (length !== this.get('length')) {
            this.set('length', length);
            this.save_changes();
        }
    }
    async setOutputs({ items }) {
        this.add(items, true);
        return this.outputAreaModel.length;
    }
    add(items, clear) {
        if (clear) {
            this.outputAreaModel.clear(false);
        }
        for (const output of items) {
            this.outputAreaModel.add(output);
        }
    }
    close(comm_closed) {
        this.outputAreaModel.changed.disconnect(this._outputAreaModelChange, this);
        this.outputAreaModel.dispose();
        return super.close(comm_closed);
    }
}
class SimpleOutputView extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.DOMWidgetView {
    initialize(parameters) {
        super.initialize(parameters);
        this.luminoWidget.removeClass('jupyter-widgets');
        this.luminoWidget.addClass('ipylab-SimpleOutput');
    }
    _createElement(tagName) {
        this.luminoWidget = new IpylabSimplifiedOutputArea({
            view: this,
            rendermime: _ipylab__WEBPACK_IMPORTED_MODULE_3__.IpylabModel.rendermime,
            contentFactory: _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1__.OutputArea.defaultContentFactory,
            model: this.model.outputAreaModel,
            promptOverlay: false
        });
        return this.luminoWidget.node;
    }
    _setElement(el) {
        if (this.el || el !== this.luminoWidget.node) {
            throw new Error('Cannot reset the DOM element.');
        }
        this.el = this.luminoWidget.node;
        this.$el = jquery__WEBPACK_IMPORTED_MODULE_2___default()(this.luminoWidget.node);
    }
}
class IpylabSimplifiedOutputArea extends _jupyterlab_outputarea__WEBPACK_IMPORTED_MODULE_1__.SimplifiedOutputArea {
    constructor(options) {
        const view = options.view;
        delete options.view;
        super(options);
        this._view = view;
    }
    processMessage(msg) {
        var _a;
        super.processMessage(msg);
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.processLuminoMessage(msg);
    }
    /**
     * Dispose the widget.
     *
     * This causes the view to be destroyed as well with 'remove'
     */
    dispose() {
        var _a;
        if (this.isDisposed) {
            return;
        }
        super.dispose();
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.remove();
        this._view = null;
    }
}


/***/ }),

/***/ "./lib/widgets/split_panel.js":
/*!************************************!*\
  !*** ./lib/widgets/split_panel.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SplitPanelModel: () => (/* binding */ SplitPanelModel),
/* harmony export */   SplitPanelView: () => (/* binding */ SplitPanelView)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _panel__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./panel */ "./lib/widgets/panel.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.


/**
 * A Lumino widget for split panels.
 */
class JupyterLuminoSplitPanelWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.SplitPanel {
    /**
     * Construct a new JupyterLuminoSplitPanelWidget.
     *
     * @param options The instantiation options for a JupyterLuminoSplitPanelWidget.
     */
    constructor(options) {
        const view = options.view;
        delete options.view;
        super(options);
        this._view = view;
    }
    /**
     * Process the Lumino message.
     *
     * Any custom Lumino widget used inside a Jupyter widget should override
     * the processMessage function like this.
     */
    processMessage(msg) {
        super.processMessage(msg);
        this._view.processLuminoMessage(msg);
    }
    /**
     * Dispose the widget.
     *
     * This causes the view to be destroyed as well with 'remove'
     */
    dispose() {
        var _a;
        if (this.isDisposed) {
            return;
        }
        super.dispose();
        (_a = this._view) === null || _a === void 0 ? void 0 : _a.remove();
        this._view = null;
    }
}
/**
 * The model for a split panel.
 */
class SplitPanelModel extends _panel__WEBPACK_IMPORTED_MODULE_1__.PanelModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'SplitPanelModel',
            _view_name: 'SplitPanelView'
        };
    }
}
/**
 * The view for a split panel.
 */
class SplitPanelView extends _panel__WEBPACK_IMPORTED_MODULE_1__.PanelView {
    initialize(parameters) {
        super.initialize(parameters);
        this.luminoWidget.removeClass('ipylab-Panel');
        this.luminoWidget.addClass('ipylab-SplitPanel');
    }
    /**
     * Create the widget and return the DOM element.
     *
     * @param tagName the tag name
     */
    _createElement(tagName) {
        this.luminoWidget = new JupyterLuminoSplitPanelWidget({
            view: this
        });
        return this.luminoWidget.node;
    }
    /**
     * Render the view.
     */
    render() {
        super.render();
        this.update_luminoWidget();
        this.listenTo(this.model, 'change:orientation', this.update_luminoWidget);
    }
    update_luminoWidget() {
        const luminoWidget = this
            .luminoWidget;
        luminoWidget.orientation = this.model.get('orientation');
    }
}


/***/ }),

/***/ "./lib/widgets/title.js":
/*!******************************!*\
  !*** ./lib/widgets/title.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TitleModel: () => (/* binding */ TitleModel)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.


/**
 * The model for a title widget.
 */
class TitleModel extends _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.WidgetModel {
    /**
     * The default attributes.
     */
    defaults() {
        return {
            ...super.defaults(),
            _model_name: 'TitleModel',
            _model_module: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_NAME,
            _model_module_version: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_VERSION,
            _view_name: null,
            _view_module: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_NAME,
            _view_module_version: _version__WEBPACK_IMPORTED_MODULE_1__.MODULE_VERSION
        };
    }
    /**
     * Initialize a LabIcon instance.
     *
     * @param attributes The base attributes.
     * @param options The initialization options.
     */
    initialize(attributes, options) {
        super.initialize(attributes, options);
        this.on('change:icon', this._iconChanged);
    }
    /**
     * Load settings into the widget
     * @param luminoWidget
     */
    update_title(title) {
        title.caption = this.get('caption');
        title.className = this.get('class_name');
        title.label = this.get('label');
        title.dataset = this.get('dataset');
        title.iconLabel = this.get('icon_label');
        const icon = this.get('icon');
        title.icon = icon ? icon.labIcon : null;
        title.iconClass = icon ? null : this.get('icon_class');
    }
    // /**
    //  * Pass on changes from the icon.
    //  */
    _iconChanged() {
        const icon = this.get('icon');
        this.listenTo(icon, 'change', () => {
            // Pass on changes from the icon.
            this.trigger('change');
        });
    }
}
TitleModel.serializers = {
    icon: { deserialize: _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.unpack_models }
};


/***/ })

}]);
//# sourceMappingURL=lib_widget_js.3ce3c2b54a7e6bc550d1.js.map