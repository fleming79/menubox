"use strict";
(self["webpackChunkipylab"] = self["webpackChunkipylab"] || []).push([["lib_plugin_js"],{

/***/ "./lib/plugin.js":
/*!***********************!*\
  !*** ./lib/plugin.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base");
/* harmony import */ var _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/codeeditor */ "webpack/sharing/consume/default/@jupyterlab/codeeditor");
/* harmony import */ var _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _version__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./version */ "./lib/version.js");
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.











const PLUGIN_ID = 'ipylab:settings';
/**
 * The command IDs used by the plugin.
 */
var CommandIDs;
(function (CommandIDs) {
    CommandIDs.restore = 'ipylab:restore';
    CommandIDs.checkStartKernel = 'ipylab:check-start-kernel';
})(CommandIDs || (CommandIDs = {}));
/**
 * The default plugin.
 */
const extension = {
    id: PLUGIN_ID,
    autoStart: true,
    requires: [
        _jupyter_widgets_base__WEBPACK_IMPORTED_MODULE_0__.IJupyterWidgetRegistry,
        _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_7__.IRenderMimeRegistry,
        _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_8__.ISettingRegistry,
        _jupyterlab_codeeditor__WEBPACK_IMPORTED_MODULE_3__.IEditorServices
    ],
    optional: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__.ILayoutRestorer,
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_2__.ICommandPalette,
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_1__.ILabShell,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__.IDefaultFileBrowser,
        _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_5__.ILauncher,
        _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_9__.ITranslator,
        _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_6__.IMainMenu
    ],
    activate: async (app, registry, rendermime, settings, editorServices, restorer, palette, labShell, defaultBrowser, launcher, translator, mainMenu) => {
        // add globals
        const exports = await Promise.all(/*! import() */[__webpack_require__.e("vendors-node_modules_jquery_dist_jquery_js"), __webpack_require__.e("lib_widget_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./widget */ "./lib/widget.js"));
        exports.IpylabModel.app = app;
        exports.IpylabModel.rendermime = rendermime;
        exports.IpylabModel.labShell = labShell;
        exports.IpylabModel.defaultBrowser = defaultBrowser;
        exports.IpylabModel.palette = palette;
        exports.IpylabModel.translator = translator;
        exports.IpylabModel.launcher = launcher;
        exports.IpylabModel.mainMenu = mainMenu;
        exports.IpylabModel.editorServices = editorServices;
        registry.registerWidget({
            name: _version__WEBPACK_IMPORTED_MODULE_10__.MODULE_NAME,
            version: _version__WEBPACK_IMPORTED_MODULE_10__.MODULE_VERSION,
            exports
        });
        let when;
        if (exports.IpylabModel.PER_KERNEL_WM) {
            app.commands.addCommand(CommandIDs.restore, {
                execute: exports.ShellModel.restoreToShell
            });
            app.commands.addCommand(CommandIDs.checkStartKernel, {
                label: 'Start or restart ipylab kernel',
                caption: 'Start or restart  the python kernel with path="ipylab".',
                execute: () => exports.JupyterFrontEndModel.startIpylabKernel(true)
            });
            palette.addItem({
                command: CommandIDs.checkStartKernel,
                category: 'ipylab',
                rank: 50
            });
            when = settings.load(PLUGIN_ID).then(async () => {
                const config = await settings.get(PLUGIN_ID, 'autostart');
                if (config.composite) {
                    await exports.JupyterFrontEndModel.startIpylabKernel();
                }
            });
            // Handle state restoration.
            if (restorer) {
                void restorer.restore(exports.IpylabModel.tracker, {
                    command: CommandIDs.restore,
                    args: widget => widget.ipylabSettings,
                    name: widget => widget.ipylabSettings.connection_id,
                    when
                });
            }
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/version.js":
/*!************************!*\
  !*** ./lib/version.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   MODULE_NAME: () => (/* binding */ MODULE_NAME),
/* harmony export */   MODULE_VERSION: () => (/* binding */ MODULE_VERSION)
/* harmony export */ });
// Copyright (c) ipylab contributors
// Distributed under the terms of the Modified BSD License.
// eslint-disable-next-line @typescript-eslint/no-var-requires
const data = __webpack_require__(/*! ../package.json */ "./package.json");
/**
 * The _model_module_version/_view_module_version this package implements.
 *
 * The html widget manager assumes that this is the same as the npm package
 * version number.
 */
const MODULE_VERSION = data.version;
/*
 * The current package name.
 */
const MODULE_NAME = data.name;


/***/ }),

/***/ "./package.json":
/*!**********************!*\
  !*** ./package.json ***!
  \**********************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"name":"ipylab","version":"2.0.0-b6","description":"Control JupyterLab from Python notebooks","keywords":["jupyter","jupyterlab","jupyterlab-extension","widgets"],"files":["lib/**/*.js","dist/*.js","style/*.css","style/*.js","style/index.js","schema/*.json"],"homepage":"https://github.com/jtpio/ipylab","bugs":{"url":"https://github.com/jtpio/ipylab/issues"},"license":"BSD-3-Clause","author":{"name":"ipylab contributors","email":""},"main":"lib/index.js","style":"style/widget.css","styleModule":"style/style.js","types":"./lib/index.d.ts","sideEffects":["style/*.css","style/style.js","style/index.js"],"repository":{"type":"git","url":"https://github.com/jtpio/ipylab"},"scripts":{"build":"jlpm build:lib && jlpm build:labextension:dev","build:labextension":"jupyter labextension build .","build:labextension:dev":"jupyter labextension build --development True .","build:lib":"tsc --sourceMap","build:lib:prod":"tsc","build:prod":"jlpm clean && jlpm build:lib:prod && jlpm build:labextension","clean":"jlpm clean:lib","clean:all":"jlpm clean:lib && jlpm clean:labextension && jlpm clean:lintcache","clean:labextension":"rimraf ipylab/labextension ipylab/_version.py","clean:lib":"rimraf lib tsconfig.tsbuildinfo","clean:lintcache":"rimraf .eslintcache .stylelintcache","deduplicate":"jlpm dlx yarn-berry-deduplicate -s fewerHighest && jlpm install","eslint":"jlpm eslint:check --fix","eslint:check":"eslint . --cache --ext .ts,.tsx","install:extension":"jlpm build","lint":"jlpm stylelint && jlpm prettier && jlpm eslint","lint:check":"jlpm stylelint:check && jlpm prettier:check && jlpm eslint:check","prepack":"npm run build","prettier":"jlpm prettier:base --write --list-different","prettier:base":"prettier \\"**/*{.ts,.tsx,.js,.jsx,.css,.json,.md}\\"","prettier:check":"jlpm prettier:base --check","stylelint":"jlpm stylelint:check --fix","stylelint:check":"stylelint --cache \\"style/**/*.css\\"","watch":"run-p watch:src watch:labextension","watch:labextension":"jupyter labextension watch .","watch:lib":"tsc -w","watch:src":"tsc -w --sourceMap"},"husky":{"hooks":{"pre-commit":"lint-staged"}},"lint-staged":{"**/*{.ts,.tsx,.js,.jsx,.css,.json,.md}":["prettier --write","git add"],"**/*{.py}":["black","git add"]},"dependencies":{"@jupyter-widgets/base":"^6.0.10","@jupyter-widgets/controls":"^5.0.11","@jupyter-widgets/jupyterlab-manager":"^5.0.13","@jupyter/ydoc":"^3.0.2","@jupyterlab/application":"^4.2.5","@jupyterlab/apputils":"^4.4.1","@jupyterlab/completer":"^4.3.1","@jupyterlab/filebrowser":"^4.2.5","@jupyterlab/launcher":"^4.2.5","@jupyterlab/mainmenu":"^4.2.5","@jupyterlab/observables":"^5.2.5","@jupyterlab/rendermime":"^4.2.5","@jupyterlab/settingregistry":"^4.2.5","@jupyterlab/tooltip":"^4.3.3","@lumino/commands":"^2.3.1","@lumino/disposable":"^2.1.3","@lumino/widgets":"^2.5.0","react":"18.3.1","webpack":"^5.99.9"},"devDependencies":{"@jupyterlab/builder":"^4.0.0","@types/expect.js":"^0.3.29","@types/json-schema":"^7.0.11","@types/node":"^22.15.29","@types/react":"^19.1.6","@typescript-eslint/eslint-plugin":"^6.1.0","@typescript-eslint/parser":"^6.1.0","css-loader":"^7.1.2","eslint":"^8.36.0","eslint-config-prettier":"^8.8.0","eslint-plugin-jsdoc":"^39.3.6","eslint-plugin-prettier":"^5.0.0","eslint-plugin-react":"^7.30.1","expect.js":"^0.3.1","lint-staged":"^15.2.9","mkdirp":"^3.0.1","npm-run-all":"^4.1.5","prettier":"^3.0.0","rimraf":"^6.0.1","stylelint":"^15.10.1","stylelint-config-recommended":"^13.0.0","stylelint-config-standard":"^34.0.0","stylelint-prettier":"^4.0.0","typescript":"^5.8.3"},"jupyterlab":{"extension":"lib/plugin","outputDir":"ipylab/labextension","schemaDir":"schema","sharedPackages":{"@jupyter-widgets/base":{"bundled":false,"singleton":true},"@jupyter-widgets/controls":{"bundled":false,"singleton":true},"@jupyter-widgets/jupyterlab-manager":{"bundled":false,"singleton":true}}},"eslintConfig":{"extends":["eslint:recommended","plugin:@typescript-eslint/eslint-recommended","plugin:@typescript-eslint/recommended","plugin:prettier/recommended"],"parser":"@typescript-eslint/parser","parserOptions":{"project":"tsconfig.json","sourceType":"module"},"plugins":["@typescript-eslint"],"rules":{"@typescript-eslint/naming-convention":["error",{"selector":"interface","format":["PascalCase"],"custom":{"regex":"^I[A-Z]","match":true}}],"@typescript-eslint/no-unused-vars":["warn",{"args":"none"}],"@typescript-eslint/no-explicit-any":"off","@typescript-eslint/no-namespace":"off","@typescript-eslint/no-use-before-define":"off","@typescript-eslint/quotes":["error","single",{"avoidEscape":true,"allowTemplateLiterals":false}],"curly":["error","all"],"eqeqeq":"error","prefer-arrow-callback":"error"}},"eslintIgnore":["node_modules","dist","coverage","**/*.d.ts","package-lock.json"],"prettier":{"singleQuote":true,"trailingComma":"none","arrowParens":"avoid","endOfLine":"auto","overrides":[{"files":["package.json","package-lock.json"],"options":{"tabWidth":4}}]},"stylelint":{"extends":["stylelint-config-recommended","stylelint-config-standard","stylelint-prettier/recommended"],"rules":{"property-no-vendor-prefix":null,"selector-no-vendor-prefix":null,"value-no-vendor-prefix":null,"selector-class-pattern":null}}}');

/***/ })

}]);
//# sourceMappingURL=lib_plugin_js.c20c28e60a8ba618bc60.js.map